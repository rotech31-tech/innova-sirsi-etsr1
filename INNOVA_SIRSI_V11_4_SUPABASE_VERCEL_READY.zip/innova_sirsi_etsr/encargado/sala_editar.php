<?php
declare(strict_types=1);require_once dirname(__DIR__).'/includes/init.php';require_role('encargado');
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);$s=db()->prepare('SELECT * FROM salas WHERE id=:id AND eliminado_en IS NULL LIMIT 1');$s->execute(['id'=>$id]);$room=$s->fetch();if(!$room){http_response_code(404);exit('Sala no encontrada.');}
$pageTitle='Editar sala';require dirname(__DIR__).'/includes/header.php';
?>
<section class="card" style="max-width:760px;margin-inline:auto"><div class="card-header"><h2><?=e($room['nombre'])?></h2></div><div class="card-body">
<form action="<?=e(url('php/sala_actualizar.php'))?>" method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$room['id']?>">
<div class="form-group"><label>Nombre</label><input name="nombre" required maxlength="100" value="<?=e($room['nombre'])?>"></div>
<div class="grid grid-2 mt-2"><div class="form-group"><label>Ubicación</label><input name="ubicacion" maxlength="150" value="<?=e((string)$room['ubicacion'])?>"></div><div class="form-group"><label>Capacidad</label><input name="capacidad" type="number" min="1" max="200" value="<?=e((string)$room['capacidad'])?>"></div></div>
<div class="form-group mt-2"><label>Descripción</label><textarea name="descripcion" maxlength="1000"><?=e((string)$room['descripcion'])?></textarea></div>
<div class="form-actions"><button class="btn btn-primary">Guardar cambios</button><a class="btn btn-secondary" href="<?=e(url('encargado/salas.php'))?>">Cancelar</a></div></form></div></section>
<?php require dirname(__DIR__).'/includes/footer.php';?>
