<?php
declare(strict_types=1);

require_once dirname(__DIR__).'/includes/init.php';
require_role('encargado');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    http_response_code(400);
    exit('Usuario no válido.');
}

$p = db();
$turn = manager_turn_id();
$stmt = $p->prepare(
    "SELECT
        u.id,
        u.nombre,
        u.apellido,
        u.cedula,
        u.email,
        u.rol,
        u.foto_perfil,
        u.activo,
        t.id AS turno_id,
        t.nombre AS turno_nombre
     FROM usuarios u
     JOIN usuario_turnos ut ON ut.usuario_id = u.id
     JOIN turnos t ON t.id = ut.turno_id
     WHERE u.id = :id
       AND u.eliminado_en IS NULL
       AND ut.eliminado_en IS NULL
       AND (u.id = :self OR ut.turno_id = :turno_where)
     ORDER BY (ut.turno_id = :turno_order) DESC
     LIMIT 1"
);
$stmt->execute([
    'id' => $id,
    'self' => (int)current_user()['id'],
    'turno_where' => $turn,
    'turno_order' => $turn,
]);

$editUser = $stmt->fetch();
if (!$editUser) {
    http_response_code(404);
    exit('Usuario no encontrado en tu turno.');
}

$pageTitle = 'Editar '.($editUser['rol'] === 'docente' ? 'profesor' : 'encargado');
require dirname(__DIR__).'/includes/header.php';
?>
<section class="card" style="max-width:820px;margin-inline:auto">
  <div class="card-header">
    <div>
      <h2><?=e($editUser['nombre'].' '.$editUser['apellido'])?></h2>
      <p class="meta mt-0"><?=e(role_label($editUser['rol']).' · Turno '.$editUser['turno_nombre'])?></p>
    </div>
  </div>

  <div class="card-body">
    <form action="<?=e(url('php/usuario_actualizar.php'))?>" method="post" enctype="multipart/form-data">
      <?=csrf_field()?>
      <input type="hidden" name="id" value="<?=(int)$editUser['id']?>">
      <input type="hidden" name="rol" value="<?=e($editUser['rol'])?>">

      <div class="grid grid-2">
        <div class="form-group">
          <label for="edit-nombre">Nombre</label>
          <input id="edit-nombre" name="nombre" maxlength="80" required value="<?=e($editUser['nombre'])?>">
        </div>
        <div class="form-group">
          <label for="edit-apellido">Apellido</label>
          <input id="edit-apellido" name="apellido" maxlength="80" required value="<?=e($editUser['apellido'])?>">
        </div>
      </div>

      <div class="grid grid-2 mt-2">
        <div class="form-group">
          <label for="edit-cedula">Cédula</label>
          <input id="edit-cedula" name="cedula" maxlength="20" inputmode="numeric" data-ci-uy required value="<?=e((string)$editUser['cedula'])?>">
          <span class="form-help" data-ci-help>Se valida el dígito verificador uruguayo.</span>
        </div>
        <div class="form-group">
          <label for="edit-email">Correo electrónico</label>
          <input id="edit-email" name="email" type="email" maxlength="150" required value="<?=e($editUser['email'])?>">
        </div>
      </div>

      <?php if ($editUser['rol'] === 'docente'): ?>
        <div class="form-group mt-2">
          <label for="edit-foto">Reemplazar foto</label>
          <input id="edit-foto" name="foto_perfil" type="file" accept="image/jpeg,image/png,image/webp">
          <span class="form-help">Opcional. Si no seleccionás una imagen, se conserva la foto actual.</span>
        </div>
      <?php endif; ?>

      <div class="security-note mt-3">
        <strong>Turno</strong>
        <p>Este registro pertenece a <strong><?=e($editUser['turno_nombre'])?></strong>. El turno se administra por separado para evitar cambios accidentales entre turnos.</p>
      </div>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit">Guardar cambios</button>
        <a class="btn btn-secondary" href="<?=e(url('encargado/usuarios.php'))?>">Cancelar</a>
      </div>
    </form>
  </div>
</section>
<?php require dirname(__DIR__).'/includes/footer.php'; ?>
