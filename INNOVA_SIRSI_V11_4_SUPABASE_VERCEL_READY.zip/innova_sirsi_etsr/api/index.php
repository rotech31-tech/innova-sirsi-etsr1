<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$uri=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
$path=trim(rawurldecode($uri),'/');
if($path==='')$path='index.php';
if(str_contains($path,'..')){http_response_code(400);exit('Ruta inválida');}
$target=$root.'/'.$path;
if(is_file($target)){
  $ext=strtolower(pathinfo($target,PATHINFO_EXTENSION));
  if($ext==='php'){chdir(dirname($target));require $target;exit;}
  $types=['css'=>'text/css; charset=UTF-8','js'=>'application/javascript; charset=UTF-8','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','webp'=>'image/webp','svg'=>'image/svg+xml'];
  if(isset($types[$ext]))header('Content-Type: '.$types[$ext]);readfile($target);exit;
}
http_response_code(404);require $root.'/404.php';
