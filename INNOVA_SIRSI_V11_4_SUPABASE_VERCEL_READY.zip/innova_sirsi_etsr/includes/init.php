<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/mail_config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/session_handler.php';

if(session_status()!==PHP_SESSION_ACTIVE){
    session_name('INNOVA_ETSR_SESSION');
    session_set_cookie_params([
        'lifetime'=>0,'path'=>'/','domain'=>'',
        'secure'=>(!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO']==='https') || (!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),
        'httponly'=>true,'samesite'=>'Lax'
    ]);
    $sessionSecret=(string)(getenv('SESSION_SECRET')?:'');
    if($sessionSecret!==''){
        session_set_save_handler(new CookieSessionHandler($sessionSecret,4*60*60),true);
    }
    session_start();
}

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/mailer.php';
require_once __DIR__ . '/password_reset.php';
