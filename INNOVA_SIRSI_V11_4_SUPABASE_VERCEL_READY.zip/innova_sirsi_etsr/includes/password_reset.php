<?php
declare(strict_types=1);

function normalize_cedula(string $value): string
{
    return preg_replace('/\D+/', '', trim($value)) ?? '';
}

function valid_cedula(string $value): bool
{
    $digits = normalize_cedula($value);

    // La CI uruguaya puede tener 6 o 7 dígitos base más el dígito verificador.
    // Al normalizar queda en 7 u 8 dígitos; las de 7 se completan con 0 a la izquierda.
    if (!preg_match('/^\d{7,8}$/', $digits)) {
        return false;
    }

    $cedula = str_pad($digits, 8, '0', STR_PAD_LEFT);
    if ($cedula === '00000000') {
        return false;
    }

    $weights = [2, 9, 8, 7, 6, 3, 4];
    $sum = 0;
    for ($i = 0; $i < 7; $i++) {
        $sum += ((int)$cedula[$i]) * $weights[$i];
    }

    $expected = (10 - ($sum % 10)) % 10;
    return $expected === (int)$cedula[7];
}

function password_reset_recent_count(int $userId): int
{
    $minutes = max(1, (int)PASSWORD_RESET_WINDOW_MINUTES);
    $sql = "SELECT COUNT(*) FROM password_resets
            WHERE usuario_id = :u
              AND creado_en >= NOW() - INTERVAL '{$minutes} minutes'";
    $s = db()->prepare($sql);
    $s->execute(['u' => $userId]);
    return (int)$s->fetchColumn();
}

function password_reset_rate_limited(int $userId): bool
{
    return password_reset_recent_count($userId) >= max(1, (int)PASSWORD_RESET_MAX_REQUESTS);
}

function create_password_reset(int $userId, ?int $requestedBy = null): array
{
    $pdo = db();
    $rawToken = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $rawToken);
    $minutes = max(5, (int)PASSWORD_RESET_MINUTES);

    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('UPDATE password_resets SET usado_en = NOW() WHERE usuario_id = :u AND usado_en IS NULL');
        $s->execute(['u' => $userId]);

        $sql = "INSERT INTO password_resets
                (usuario_id, solicitado_por, token_hash, expira_en, ip_solicitud)
                VALUES (:u, :r, :h, NOW() + INTERVAL '{$minutes} minutes', :ip) RETURNING id";
        $s = $pdo->prepare($sql);
        $s->execute([
            'u' => $userId,
            'r' => $requestedBy,
            'h' => $tokenHash,
            'ip' => client_ip(),
        ]);
        $resetId = (int)$s->fetchColumn();
        $pdo->commit();

        return [
            'id' => $resetId,
            'token' => $rawToken,
            'expires_minutes' => $minutes,
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function send_password_reset_email(array $user, string $rawToken, int $minutes): bool
{
    $link = absolute_url('restablecer_password.php?token=' . urlencode($rawToken));
    $name = trim(($user['nombre'] ?? '') . ' ' . ($user['apellido'] ?? ''));
    $safeName = e($name);
    $safeLink = e($link);
    $system = e(APP_NAME);
    $company = e(COMPANY_NAME);

    $subject = 'Recuperación de contraseña - ' . APP_SHORT_NAME;

    $html = <<<HTML
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"></head>
<body style="font-family:Arial,sans-serif;color:#172033;line-height:1.6">
  <div style="max-width:620px;margin:auto;border:1px solid #dce3ec;border-radius:14px;overflow:hidden">
    <div style="background:#0b1f3a;color:#fff;padding:22px 26px">
      <strong style="font-size:18px">{$system}</strong><br>
      <span style="color:#bcd0e7">{$company}</span>
    </div>
    <div style="padding:26px">
      <p>Hola {$safeName}:</p>
      <p>Se solicitó restablecer la contraseña de tu cuenta.</p>
      <p style="margin:28px 0">
        <a href="{$safeLink}" style="background:#1769aa;color:#fff;padding:12px 18px;border-radius:9px;text-decoration:none;font-weight:bold">
          Restablecer contraseña
        </a>
      </p>
      <p>Este enlace vence en <strong>{$minutes} minutos</strong> y puede utilizarse una sola vez.</p>
      <p>Si no realizaste esta solicitud, puedes ignorar este correo. Tu contraseña actual seguirá siendo válida.</p>
      <hr style="border:0;border-top:1px solid #e5e7eb;margin:24px 0">
      <small style="color:#687386">Por seguridad, no compartas este enlace con otras personas.</small>
    </div>
  </div>
</body>
</html>
HTML;

    $text = "Hola {$name}:\n\n"
          . "Se solicitó restablecer la contraseña de tu cuenta en " . APP_NAME . ".\n\n"
          . "Abre este enlace:\n{$link}\n\n"
          . "El enlace vence en {$minutes} minutos y puede utilizarse una sola vez.\n"
          . "Si no realizaste esta solicitud, ignora este correo.\n\n"
          . COMPANY_NAME;

    return send_system_mail((string)$user['email'], $name, $subject, $html, $text);
}

function find_valid_password_reset(string $rawToken): ?array
{
    if (!preg_match('/^[a-f0-9]{64}$/', $rawToken)) {
        return null;
    }

    $hash = hash('sha256', $rawToken);
    $s = db()->prepare(
        "SELECT pr.id reset_id, pr.usuario_id, pr.expira_en,
                u.nombre, u.apellido, u.email, u.rol, u.activo
         FROM password_resets pr
         JOIN usuarios u ON u.id = pr.usuario_id
         WHERE pr.token_hash = :h
           AND pr.usado_en IS NULL
           AND pr.expira_en >= NOW()
           AND u.activo = 1
           AND u.eliminado_en IS NULL
           AND EXISTS (SELECT 1 FROM usuario_turnos ut WHERE ut.usuario_id=u.id AND ut.activo=1 AND ut.eliminado_en IS NULL)
         LIMIT 1"
    );
    $s->execute(['h' => $hash]);
    $row = $s->fetch();
    return $row ?: null;
}

function complete_password_reset(string $rawToken, string $newPassword): ?int
{
    $reset = find_valid_password_reset($rawToken);
    if (!$reset) {
        return null;
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        // Se vuelve a bloquear la fila dentro de la transacción para evitar reutilización simultánea.
        $hash = hash('sha256', $rawToken);
        $s = $pdo->prepare(
            "SELECT id, usuario_id
             FROM password_resets
             WHERE token_hash = :h
               AND usado_en IS NULL
               AND expira_en >= NOW()
             FOR UPDATE"
        );
        $s->execute(['h' => $hash]);
        $locked = $s->fetch();
        if (!$locked) {
            $pdo->rollBack();
            return null;
        }

        $userId = (int)$locked['usuario_id'];
        $s = $pdo->prepare('UPDATE usuarios SET password_hash = :p WHERE id = :u AND activo = 1 AND eliminado_en IS NULL');
        $s->execute([
            'p' => password_hash($newPassword, PASSWORD_BCRYPT),
            'u' => $userId,
        ]);
        if ($s->rowCount() !== 1) {
            $pdo->rollBack();
            return null;
        }

        $s = $pdo->prepare('UPDATE password_resets SET usado_en = NOW() WHERE usuario_id = :u AND usado_en IS NULL');
        $s->execute(['u' => $userId]);
        $pdo->commit();
        return $userId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}
