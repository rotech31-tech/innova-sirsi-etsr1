<?php
declare(strict_types=1);

define('APP_NAME', 'Sistema Integral de Relevamiento de Salas de Informática ETSR - UTU');
define('APP_SHORT_NAME', 'Relevamiento ETSR - UTU');
define('COMPANY_NAME', 'INNOVA SRL');

$base = rtrim((string)(getenv('APP_BASE_URL') ?: ''), '/');
define('BASE_URL', $base);
$origin = (string)(getenv('APP_ORIGIN') ?: '');
if ($origin === '') {
    $proto = (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) ? (string)$_SERVER['HTTP_X_FORWARDED_PROTO'] : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http'));
    $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
    $origin = $proto . '://' . $host;
}
define('APP_ORIGIN', rtrim($origin, '/'));

define('DB_HOST', (string)(getenv('DB_HOST') ?: '127.0.0.1'));
define('DB_PORT', (string)(getenv('DB_PORT') ?: '5432'));
define('DB_NAME', (string)(getenv('DB_NAME') ?: 'postgres'));
define('DB_USER', (string)(getenv('DB_USER') ?: 'postgres'));
define('DB_PASS', (string)(getenv('DB_PASS') ?: ''));
define('DB_SCHEMA', (string)(getenv('DB_SCHEMA') ?: 'app'));

define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);
date_default_timezone_set('America/Montevideo');
