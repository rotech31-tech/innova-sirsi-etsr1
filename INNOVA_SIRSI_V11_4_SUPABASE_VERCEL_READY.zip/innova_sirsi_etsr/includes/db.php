<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = sprintf('pgsql:host=%s;port=%s;dbname=%s;sslmode=require', DB_HOST, DB_PORT, DB_NAME);
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => true,
        ]);
        $schema = preg_replace('/[^a-zA-Z0-9_]/', '', DB_SCHEMA) ?: 'app';
        $pdo->exec('SET search_path TO ' . $schema . ', public');
        $pdo->exec("SET TIME ZONE 'America/Montevideo'");
    } catch (PDOException $e) {
        http_response_code(500);
        exit('<h1>Error de conexión</h1><p>No se pudo conectar con la base de datos del sistema.</p>');
    }
    return $pdo;
}
