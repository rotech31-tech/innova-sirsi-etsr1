<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Correo institucional del sistema
|--------------------------------------------------------------------------
| Completa estos datos cuando UTU te entregue la cuenta institucional.
| NO uses el correo personal del Encargado de Sala.
| NO compartas este archivo una vez que contenga una contraseña real.
|
| Ejemplos de cifrado:
|   'tls' = STARTTLS (habitualmente puerto 587)
|   'ssl' = TLS implícito (habitualmente puerto 465)
|   ''    = sin cifrado (no recomendado fuera de una red controlada)
|
| Los valores exactos de HOST, PUERTO y CIFRADO deben ser los que indique UTU.
*/

define('MAIL_ENABLED', false);          // Cambiar a true cuando completes todos los datos.
define('MAIL_HOST', '');                // Ej.: smtp.institucion.edu.uy
define('MAIL_PORT', 587);
define('MAIL_SMTP_AUTH', true);
define('MAIL_USERNAME', '');            // Correo institucional completo.
define('MAIL_PASSWORD', '');            // Contraseña o clave de aplicación entregada por UTU.
define('MAIL_ENCRYPTION', 'tls');       // 'tls', 'ssl' o ''
define('MAIL_FROM_ADDRESS', '');        // Normalmente el mismo valor que MAIL_USERNAME.
define('MAIL_FROM_NAME', APP_SHORT_NAME);
define('MAIL_REPLY_TO', '');            // Opcional.

define('PASSWORD_RESET_MINUTES', 30);
define('PASSWORD_RESET_MAX_REQUESTS', 3);
define('PASSWORD_RESET_WINDOW_MINUTES', 30);
