</main>
<footer class="site-footer">
  <div class="container footer-content">
    <div><strong>Escuela Técnica Superior de Rivera · UTU</strong><span><?=e(APP_NAME)?></span></div>
    <div class="system-health"><span class="health-dot" aria-hidden="true"></span><span>Sistema operativo</span><span>Base de datos conectada</span><span>Actualizado <?=date('H:i')?></span></div>
    <div class="footer-credit"><span>Desarrollado por <?=e(COMPANY_NAME)?></span><small>Proyecto Final · Bachillerato Tecnológico en Soporte Técnico · <?=date('Y')?></small></div>
  </div>
</footer>
<script src="<?=e(url('assets/js/app.js'))?>"></script>
</body></html>
