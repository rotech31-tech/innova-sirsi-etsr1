<?php
declare(strict_types=1);

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $path = ''): string { return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/'); }
function absolute_url(string $path = ''): string { return rtrim(APP_ORIGIN, '/') . url($path); }
function redirect(string $path): never { header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path))); exit; }
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function csrf_token(): string { if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); return $_SESSION['csrf_token']; }
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void { $token = (string)($_POST['csrf_token'] ?? ''); if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) { http_response_code(419); exit('Formulario vencido. Actualiza la página.'); } }
function flash(string $type, string $message): void { $_SESSION['flash'][] = ['type'=>$type,'message'=>$message]; }
function pull_flashes(): array { $m = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $m; }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function is_logged_in(): bool { return isset($_SESSION['user']['id']); }
function require_login(): void {
    if (!is_logged_in()) {
        $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'] ?? url('dashboard.php');
        flash('warning','Debes iniciar sesión.');
        redirect('login.php');
    }
    $u=current_user();
    $sql="SELECT COUNT(*) FROM usuarios u WHERE u.id=:id AND u.activo=1 AND u.eliminado_en IS NULL AND EXISTS (SELECT 1 FROM usuario_turnos ut WHERE ut.usuario_id=u.id AND ut.activo=1 AND ut.eliminado_en IS NULL";
    $params=['id'=>(int)$u['id']];
    if(($u['rol']??'')==='encargado'){
        $sql.=' AND ut.turno_id=:turno';
        $params['turno']=(int)($u['turno_id']??0);
    }
    $sql.=')';
    try{$s=db()->prepare($sql);$s->execute($params);$ok=(int)$s->fetchColumn()>0;}catch(Throwable $e){$ok=false;}
    if(!$ok){
        unset($_SESSION['user']);
        flash('danger','Tu cuenta o turno ya no están activos.');
        redirect('login.php');
    }
}
function require_role(string ...$roles): void { require_login(); if (!in_array(current_user()['rol'] ?? '', $roles, true)) { http_response_code(403); redirect('acceso_denegado.php'); } }
function is_encargado(): bool { return (current_user()['rol'] ?? '') === 'encargado'; }
function is_docente(): bool { return (current_user()['rol'] ?? '') === 'docente'; }
function role_label(string $role): string { return ['encargado'=>'Encargado de Sala','docente'=>'Docente'][$role] ?? ucfirst($role); }
function manager_turn_id(): int { return is_encargado() ? (int)(current_user()['turno_id'] ?? 0) : 0; }
function manager_turn_name(): string { return is_encargado() ? (string)(current_user()['turno_nombre'] ?? '') : ''; }
function turn_name(int $turnId): string { return [1=>'Matutino',2=>'Vespertino',3=>'Nocturno'][$turnId] ?? 'Sin turno'; }
function active_turns_for_user(int $userId): array {
    $s=db()->prepare("SELECT t.id,t.codigo,t.nombre FROM usuario_turnos ut JOIN turnos t ON t.id=ut.turno_id WHERE ut.usuario_id=:u AND ut.activo=1 AND ut.eliminado_en IS NULL AND t.activo=1 ORDER BY t.id");
    $s->execute(['u'=>$userId]);
    return $s->fetchAll();
}
function user_has_turn(int $userId, int $turnId, bool $onlyActive=true): bool {
    $sql='SELECT COUNT(*) FROM usuario_turnos WHERE usuario_id=:u AND turno_id=:t AND eliminado_en IS NULL';
    if($onlyActive)$sql.=' AND activo=1';
    $s=db()->prepare($sql);$s->execute(['u'=>$userId,'t'=>$turnId]);return (int)$s->fetchColumn()>0;
}
function refresh_user_global_active(int $userId): void {
    $s=db()->prepare('SELECT COUNT(*) FROM usuario_turnos WHERE usuario_id=:u AND activo=1 AND eliminado_en IS NULL');$s->execute(['u'=>$userId]);
    $active=(int)$s->fetchColumn()>0?1:0;
    db()->prepare('UPDATE usuarios SET activo=:a WHERE id=:u AND eliminado_en IS NULL')->execute(['a'=>$active,'u'=>$userId]);
}
function can_manage_user_in_current_turn(int $userId): bool {
    $turn=manager_turn_id(); if(!$turn)return false;
    $s=db()->prepare("SELECT u.rol FROM usuarios u JOIN usuario_turnos ut ON ut.usuario_id=u.id WHERE u.id=:u AND u.eliminado_en IS NULL AND ut.turno_id=:t AND ut.eliminado_en IS NULL LIMIT 1");
    $s->execute(['u'=>$userId,'t'=>$turn]);return (bool)$s->fetch();
}
function input_string(string $key, int $max=255): string { $v=trim((string)($_POST[$key] ?? '')); return function_exists('mb_substr')?mb_substr($v,0,$max,'UTF-8'):substr($v,0,$max); }
function nullable_string(string $key, int $max=255): ?string { $v = input_string($key,$max); return $v === '' ? null : $v; }
function input_int(string $key): ?int { $v = filter_input(INPUT_POST,$key,FILTER_VALIDATE_INT); return ($v===false||$v===null)?null:$v; }
function generate_qr_token(): string { return bin2hex(random_bytes(24)); }
function client_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? 'desconocida'),0,45); }
function log_activity(string $action, ?string $entity=null, ?int $entityId=null, ?string $detail=null): void {
    try { $s=db()->prepare('INSERT INTO log_actividad(usuario_id,accion,entidad,entidad_id,detalle,ip) VALUES(:u,:a,:e,:i,:d,:ip)'); $s->execute(['u'=>current_user()['id']??null,'a'=>mb_substr($action,0,100),'e'=>$entity,'i'=>$entityId,'d'=>$detail,'ip'=>client_ip()]); } catch(Throwable $e) {}
}
function upload_image(string $field, string $subfolder, bool $required=false): ?string {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error']===UPLOAD_ERR_NO_FILE) { if($required) throw new RuntimeException('Debes seleccionar una imagen.'); return null; }
    $f=$_FILES[$field];
    if($f['error']!==UPLOAD_ERR_OK) throw new RuntimeException('La imagen no pudo subirse.');
    if((int)$f['size']>MAX_UPLOAD_SIZE) throw new RuntimeException('La imagen supera 5 MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowed=['image/jpeg','image/png','image/webp'];
    if(!in_array($mime,$allowed,true)) throw new RuntimeException('Usa JPG, PNG o WEBP.');
    $bytes=file_get_contents($f['tmp_name']);
    if($bytes===false) throw new RuntimeException('No se pudo leer la imagen.');
    $token=bin2hex(random_bytes(24));
    $q=db()->prepare('INSERT INTO archivos(token,categoria,mime,nombre_original,contenido,tamano) VALUES(:t,:c,:m,:n,:b,:s)');
    $q->bindValue(':t',$token); $q->bindValue(':c',preg_replace('/[^a-z0-9_-]/i','',$subfolder));
    $q->bindValue(':m',$mime); $q->bindValue(':n',(string)($f['name']??''));
    $q->bindValue(':b',$bytes,PDO::PARAM_LOB); $q->bindValue(':s',(int)$f['size'],PDO::PARAM_INT); $q->execute();
    return 'archivo.php?t='.$token;
}
function active_menu(string $needle): string { return str_contains($_SERVER['PHP_SELF'] ?? '',$needle)?'active':''; }
function status_badge(string $s): string {
    $m=['abierto'=>'danger','en_revision'=>'warning','en_proceso'=>'info','resuelto'=>'success','cerrado'=>'neutral','operativo'=>'success','con_falla'=>'danger','mantenimiento'=>'warning','baja'=>'neutral','media'=>'info','alta'=>'warning','critica'=>'danger','en_sala'=>'success','pendiente_registro'=>'warning','proximo'=>'info','sin_registro'=>'danger','finalizado'=>'neutral'];
    $labels=['en_sala'=>'En sala','pendiente_registro'=>'Pendiente de registro','proximo'=>'Próximo','sin_registro'=>'Sin registro','finalizado'=>'Finalizado'];
    $label=$labels[$s]??ucwords(str_replace('_',' ',$s));
    return '<span class="badge badge-'.e($m[$s]??'neutral').'">'.e($label).'</span>';
}
function safe_intended_url(): string { $i=$_SESSION['intended_url']??''; unset($_SESSION['intended_url']); return is_string($i)&&str_starts_with($i,rtrim(BASE_URL,'/').'/')?$i:url('dashboard.php'); }
function day_name(int $day): string { return [1=>'Lunes',2=>'Martes',3=>'Miércoles',4=>'Jueves',5=>'Viernes'][$day] ?? 'Día no lectivo'; }
function format_time(?string $time): string { return $time ? substr($time,0,5) : '-'; }
function equipment_type_label(string $type): string { return ['pc'=>'PC','torre'=>'Torre','monitor'=>'Monitor','switch'=>'Switch','router'=>'Router','impresora'=>'Impresora','access_point'=>'Access Point'][$type] ?? ucwords(str_replace('_',' ',$type)); }
function valid_time(string $time): bool { return (bool)preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/',$time); }
function valid_date(string $date): bool { $d=DateTime::createFromFormat('Y-m-d',$date); return $d && $d->format('Y-m-d')===$date; }

function sync_assignment_from_schedules(int $docenteId, int $salaId, int $anio, int $turnoId): void {
    $p=db();
    $q=$p->prepare('SELECT COUNT(*) FROM horarios_docentes WHERE docente_id=:d AND sala_id=:s AND turno_id=:t AND anio_lectivo=:y AND activo=1 AND eliminado_en IS NULL');
    $q->execute(['d'=>$docenteId,'s'=>$salaId,'t'=>$turnoId,'y'=>$anio]);
    $active=(int)$q->fetchColumn()>0 ? 1 : 0;
    if($active){
        $q=$p->prepare('INSERT INTO asignaciones_salas(docente_id,sala_id,turno_id,anio_lectivo,activa) VALUES(:d,:s,:t,:y,1) ON CONFLICT (docente_id,sala_id,turno_id,anio_lectivo) DO UPDATE SET activa=1');
        $q->execute(['d'=>$docenteId,'s'=>$salaId,'t'=>$turnoId,'y'=>$anio]);
    }else{
        $q=$p->prepare('UPDATE asignaciones_salas SET activa=0 WHERE docente_id=:d AND sala_id=:s AND turno_id=:t AND anio_lectivo=:y');
        $q->execute(['d'=>$docenteId,'s'=>$salaId,'t'=>$turnoId,'y'=>$anio]);
    }
}


function format_datetime(?string $value): string {
    if (!$value) return '-';
    try { return (new DateTime($value))->format('d/m/Y H:i'); } catch(Throwable $e) { return $value; }
}
function room_status_info(int $roomId): array {
    $p=db();
    $s=$p->prepare("SELECT COUNT(*) FROM sesiones_sala WHERE sala_id=:s AND checkout_en IS NULL");
    $s->execute(['s'=>$roomId]);
    if((int)$s->fetchColumn()>0) return ['key'=>'en_uso','label'=>'En uso','class'=>'info'];
    $s=$p->prepare("SELECT COUNT(*) FROM tickets WHERE sala_id=:s AND estado IN('abierto','en_revision','en_proceso')");
    $s->execute(['s'=>$roomId]);
    if((int)$s->fetchColumn()>0) return ['key'=>'incidencia','label'=>'Con incidencia','class'=>'danger'];
    $s=$p->prepare("SELECT COUNT(*) FROM equipos WHERE sala_id=:s AND activo=1 AND eliminado_en IS NULL AND estado IN('con_falla','mantenimiento')");
    $s->execute(['s'=>$roomId]);
    if((int)$s->fetchColumn()>0) return ['key'=>'incidencia','label'=>'Con incidencia','class'=>'warning'];
    return ['key'=>'disponible','label'=>'Disponible','class'=>'success'];
}
function room_status_badge(int $roomId): string {
    $st=room_status_info($roomId);
    return '<span class="badge badge-'.e($st['class']).'">'.e($st['label']).'</span>';
}
function can_view_room(int $roomId): bool {
    if(is_encargado()) return true;
    if(!is_docente()) return false;
    $s=db()->prepare("SELECT COUNT(*) FROM asignaciones_salas WHERE docente_id=:d AND sala_id=:s AND anio_lectivo=YEAR(CURDATE()) AND activa=1");
    $s->execute(['d'=>(int)current_user()['id'],'s'=>$roomId]);
    return (int)$s->fetchColumn()>0;
}
function csv_download_headers(string $filename): void {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    echo "\xEF\xBB\xBF";
}
