<?php
declare(strict_types=1);

function mail_is_configured(): bool
{
    return defined('MAIL_ENABLED')
        && MAIL_ENABLED === true
        && trim((string)MAIL_HOST) !== ''
        && (int)MAIL_PORT > 0
        && trim((string)MAIL_FROM_ADDRESS) !== ''
        && filter_var(MAIL_FROM_ADDRESS, FILTER_VALIDATE_EMAIL)
        && (!MAIL_SMTP_AUTH || (trim((string)MAIL_USERNAME) !== '' && (string)MAIL_PASSWORD !== ''));
}

function send_system_mail(string $toEmail, string $toName, string $subject, string $htmlBody, string $textBody): bool
{
    if (!mail_is_configured() || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        error_log('[INNOVA MAIL] Correo no configurado o destinatario inválido.');
        return false;
    }

    $autoload = dirname(__DIR__) . '/vendor/autoload.php';

    if (is_file($autoload)) {
        require_once $autoload;
        if (class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
            try {
                $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = MAIL_HOST;
                $mail->Port = (int)MAIL_PORT;
                $mail->SMTPAuth = (bool)MAIL_SMTP_AUTH;
                if (MAIL_SMTP_AUTH) {
                    $mail->Username = MAIL_USERNAME;
                    $mail->Password = MAIL_PASSWORD;
                }

                if (MAIL_ENCRYPTION === 'tls') {
                    $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                } elseif (MAIL_ENCRYPTION === 'ssl') {
                    $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                } else {
                    $mail->SMTPSecure = '';
                    $mail->SMTPAutoTLS = false;
                }

                $mail->CharSet = 'UTF-8';
                $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
                if (defined('MAIL_REPLY_TO') && MAIL_REPLY_TO !== '' && filter_var(MAIL_REPLY_TO, FILTER_VALIDATE_EMAIL)) {
                    $mail->addReplyTo(MAIL_REPLY_TO);
                }
                $mail->addAddress($toEmail, $toName);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $htmlBody;
                $mail->AltBody = $textBody;
                $mail->send();
                return true;
            } catch (Throwable $e) {
                error_log('[INNOVA MAIL][PHPMailer] ' . $e->getMessage());
                return false;
            }
        }
    }

    // Respaldo autónomo para XAMPP cuando Composer/PHPMailer todavía no esté instalado.
    // Utiliza SMTP autenticado y TLS según includes/mail_config.php.
    try {
        return smtp_send_basic($toEmail, $toName, $subject, $htmlBody, $textBody);
    } catch (Throwable $e) {
        error_log('[INNOVA MAIL][SMTP] ' . $e->getMessage());
        return false;
    }
}

function smtp_send_basic(string $toEmail, string $toName, string $subject, string $htmlBody, string $textBody): bool
{
    $scheme = MAIL_ENCRYPTION === 'ssl' ? 'ssl://' : '';
    $remote = $scheme . MAIL_HOST . ':' . (int)MAIL_PORT;
    $errno = 0;
    $errstr = '';

    $socket = @stream_socket_client($remote, $errno, $errstr, 15, STREAM_CLIENT_CONNECT);
    if (!is_resource($socket)) {
        throw new RuntimeException('No se pudo conectar al servidor SMTP: ' . $errstr);
    }
    stream_set_timeout($socket, 15);

    smtp_expect($socket, [220]);
    $hostName = gethostname() ?: 'localhost';
    smtp_command($socket, 'EHLO ' . $hostName, [250]);

    if (MAIL_ENCRYPTION === 'tls') {
        smtp_command($socket, 'STARTTLS', [220]);
        $cryptoMethod = defined('STREAM_CRYPTO_METHOD_TLS_CLIENT')
            ? STREAM_CRYPTO_METHOD_TLS_CLIENT
            : STREAM_CRYPTO_METHOD_SSLv23_CLIENT;
        if (!@stream_socket_enable_crypto($socket, true, $cryptoMethod)) {
            fclose($socket);
            throw new RuntimeException('No se pudo iniciar una conexión TLS con el servidor SMTP.');
        }
        smtp_command($socket, 'EHLO ' . $hostName, [250]);
    }

    if (MAIL_SMTP_AUTH) {
        smtp_command($socket, 'AUTH LOGIN', [334]);
        smtp_command($socket, base64_encode((string)MAIL_USERNAME), [334]);
        smtp_command($socket, base64_encode((string)MAIL_PASSWORD), [235]);
    }

    smtp_command($socket, 'MAIL FROM:<' . MAIL_FROM_ADDRESS . '>', [250]);
    smtp_command($socket, 'RCPT TO:<' . $toEmail . '>', [250, 251]);
    smtp_command($socket, 'DATA', [354]);

    $boundary = 'b_' . bin2hex(random_bytes(12));
    $fromName = smtp_mime_header((string)MAIL_FROM_NAME);
    $toDisplay = trim($toName) !== '' ? smtp_mime_header($toName) . ' <' . $toEmail . '>' : '<' . $toEmail . '>';
    $encodedSubject = smtp_mime_header($subject);

    $headers = [
        'Date: ' . date(DATE_RFC2822),
        'From: ' . $fromName . ' <' . MAIL_FROM_ADDRESS . '>',
        'To: ' . $toDisplay,
        'Subject: ' . $encodedSubject,
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . preg_replace('/[^a-z0-9.-]/i', '', MAIL_HOST) . '>',
    ];

    if (defined('MAIL_REPLY_TO') && MAIL_REPLY_TO !== '' && filter_var(MAIL_REPLY_TO, FILTER_VALIDATE_EMAIL)) {
        $headers[] = 'Reply-To: ' . MAIL_REPLY_TO;
    }

    $message = implode("\r\n", $headers) . "\r\n\r\n";
    $message .= '--' . $boundary . "\r\n";
    $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
    $message .= chunk_split(base64_encode($textBody), 76, "\r\n") . "\r\n";
    $message .= '--' . $boundary . "\r\n";
    $message .= "Content-Type: text/html; charset=UTF-8\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
    $message .= chunk_split(base64_encode($htmlBody), 76, "\r\n") . "\r\n";
    $message .= '--' . $boundary . "--\r\n";

    // Dot-stuffing obligatorio para el cuerpo SMTP DATA.
    $message = preg_replace('/(?m)^\./', '..', $message) ?? $message;
    fwrite($socket, $message . "\r\n.\r\n");
    smtp_expect($socket, [250]);

    try {
        smtp_command($socket, 'QUIT', [221]);
    } catch (Throwable $e) {
        // El mensaje ya fue aceptado por el servidor; no se invalida el envío por un error al cerrar.
    }
    fclose($socket);
    return true;
}

function smtp_command($socket, string $command, array $expectedCodes): string
{
    fwrite($socket, $command . "\r\n");
    return smtp_expect($socket, $expectedCodes);
}

function smtp_expect($socket, array $expectedCodes): string
{
    $response = '';
    $code = 0;

    while (($line = fgets($socket, 515)) !== false) {
        $response .= $line;
        if (preg_match('/^(\d{3})([ -])/', $line, $m)) {
            $code = (int)$m[1];
            if ($m[2] === ' ') {
                break;
            }
        }
    }

    if (!in_array($code, $expectedCodes, true)) {
        throw new RuntimeException('Respuesta SMTP inesperada (' . $code . '): ' . trim($response));
    }
    return $response;
}

function smtp_mime_header(string $value): string
{
    if (function_exists('mb_encode_mimeheader')) {
        return mb_encode_mimeheader($value, 'UTF-8', 'B', "\r\n");
    }
    return '=?UTF-8?B?' . base64_encode($value) . '?=';
}
