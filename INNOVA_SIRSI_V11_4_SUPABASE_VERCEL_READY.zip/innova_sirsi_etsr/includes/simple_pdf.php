<?php
declare(strict_types=1);

final class SimplePdf
{
    private array $pages = [];

    private function enc(string $text): string
    {
        $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
        if ($converted === false) $converted = $text;
        return str_replace(['\\','(',')'], ['\\\\','\\(','\\)'], $converted);
    }

    private function shorten(string $text, int $max): string
    {
        $chars = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($chars) || count($chars) <= $max) return $text;
        return implode('', array_slice($chars, 0, max(0, $max-1))).'…';
    }

    private function text(float $x, float $y, float $size, string $text, bool $bold=false): string
    {
        $font = $bold ? 'F2' : 'F1';
        return sprintf("BT /%s %.1f Tf %.1f %.1f Td (%s) Tj ET\n", $font, $size, $x, $y, $this->enc($text));
    }

    private function line(float $x1, float $y1, float $x2, float $y2): string
    {
        return sprintf("%.1f %.1f m %.1f %.1f l S\n", $x1, $y1, $x2, $y2);
    }

    public function addAttendancePage(string $room, string $dateLabel, array $rows, bool $showRoomColumn=true): void
    {
        $chunks = array_chunk($rows ?: [['docente'=>'Sin registros programados','sala'=>$room,'ingreso'=>'-','salida'=>'-']], 28);
        foreach ($chunks as $pageIndex => $chunk) {
            $c = "0 G 0.7 w\n";
            $c .= $this->text(48, 800, 15, 'Sistema Integral de Relevamiento de Salas de Informática ETSR - UTU', true);
            $c .= $this->text(48, 780, 10, 'INNOVA SRL · Escuela Técnica Superior de Rivera - UTU');
            $c .= $this->text(48, 750, 13, 'Planilla digital de conexión docente', true);
            $c .= $this->text(48, 732, 10, 'Sala: '.$room.'    Fecha: '.$dateLabel.($pageIndex ? '    Continuación' : ''));

            $y = 700;
            $x = [48, 292, 380, 465, 548];
            $c .= $this->line(48, $y+18, 548, $y+18);
            $c .= $this->line(48, $y-4, 548, $y-4);
            $c .= $this->text(54, $y+2, 9, 'Docente', true);
            if ($showRoomColumn) $c .= $this->text(298, $y+2, 9, 'Sala', true);
            $c .= $this->text(386, $y+2, 9, 'Ingreso', true);
            $c .= $this->text(471, $y+2, 9, 'Salida', true);
            foreach ($x as $vx) $c .= $this->line($vx, $y+18, $vx, $y-4 - (count($chunk)*22));

            $rowY = $y-22;
            foreach ($chunk as $r) {
                $name = $this->shorten((string)$r['docente'], 38);
                $roomCell = $this->shorten((string)$r['sala'], 13);
                $c .= $this->text(54, $rowY+4, 9, $name);
                if ($showRoomColumn) $c .= $this->text(298, $rowY+4, 9, $roomCell);
                $c .= $this->text(386, $rowY+4, 9, (string)$r['ingreso']);
                $c .= $this->text(471, $rowY+4, 9, (string)$r['salida']);
                $c .= $this->line(48, $rowY-4, 548, $rowY-4);
                $rowY -= 22;
            }
            $c .= $this->text(48, 52, 8, 'Documento generado automáticamente por el sistema · Desarrollado por INNOVA SRL');
            $this->pages[] = $c;
        }
    }

    public function output(string $filename): never
    {
        $n = count($this->pages);
        $font1 = 3 + ($n * 2);
        $font2 = $font1 + 1;
        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = [];
        for ($i=0; $i<$n; $i++) $kids[] = (3 + $i*2).' 0 R';
        $objects[2] = '<< /Type /Pages /Kids ['.implode(' ', $kids).'] /Count '.$n.' >>';
        for ($i=0; $i<$n; $i++) {
            $pageObj = 3 + $i*2;
            $contentObj = $pageObj + 1;
            $stream = $this->pages[$i];
            $objects[$pageObj] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 '.$font1.' 0 R /F2 '.$font2.' 0 R >> >> /Contents '.$contentObj.' 0 R >>';
            $objects[$contentObj] = "<< /Length ".strlen($stream)." >>\nstream\n".$stream."endstream";
        }
        $objects[$font1] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[$font2] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        ksort($objects);

        $pdf = "%PDF-1.4\n%âãÏÓ\n";
        $offsets = [0=>0];
        foreach ($objects as $id=>$obj) {
            $offsets[$id] = strlen($pdf);
            $pdf .= $id." 0 obj\n".$obj."\nendobj\n";
        }
        $xref = strlen($pdf);
        $count = max(array_keys($objects))+1;
        $pdf .= "xref\n0 ".$count."\n0000000000 65535 f \n";
        for ($i=1; $i<$count; $i++) $pdf .= sprintf("%010d 00000 n \n", $offsets[$i] ?? 0);
        $pdf .= "trailer\n<< /Size ".$count." /Root 1 0 R >>\nstartxref\n".$xref."\n%%EOF";

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="'.preg_replace('/[^A-Za-z0-9_.-]/','_',$filename).'"');
        header('Content-Length: '.strlen($pdf));
        echo $pdf;
        exit;
    }
}
