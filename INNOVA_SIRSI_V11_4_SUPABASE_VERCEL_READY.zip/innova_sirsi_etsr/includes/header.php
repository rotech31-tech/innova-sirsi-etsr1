<?php
$pageTitle = $pageTitle ?? APP_SHORT_NAME;
$sessionUser = current_user();
$flashes = pull_flashes();
$currentPath = str_replace('\\', '/', $_SERVER['PHP_SELF'] ?? '');
$isDashboard = str_contains($currentPath, '/dashboard.php');
$navActive = static function (string $needle) use ($currentPath): string { return str_contains($currentPath, $needle) ? ' active' : ''; };
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#102737">
  <title><?=e($pageTitle)?> | <?=e(APP_SHORT_NAME)?></title>
  <link rel="stylesheet" href="<?=e(url('assets/css/styles.css'))?>">
</head>
<body class="<?=$sessionUser?'app-body':'auth-body'?>">
<?php if($sessionUser): ?>
<div class="institution-bar">
  <div class="container institution-bar__content"><span>Escuela Técnica Superior de Rivera · DGETP — UTU</span><span class="institution-bar__company">Sistema desarrollado por <?=e(COMPANY_NAME)?></span></div>
</div>
<header class="topbar">
  <div class="container nav-wrap">
    <a class="brand" href="<?=e(url('dashboard.php'))?>" aria-label="Ir al panel principal"><span class="brand-mark" aria-hidden="true"><strong>ETSR</strong><small>UTU</small></span><span class="brand-copy"><strong>Sistema Integral de Relevamiento</strong><small>Salas de Informática · Rivera</small></span></a>
    <div class="header-tools">
      <form class="header-search" action="<?=e(url('buscar.php'))?>" method="get"><label class="sr-only" for="header-q">Buscar</label><input id="header-q" name="q" placeholder="Buscar en el sistema" value="<?=e((string)($_GET['q']??''))?>"><button>Buscar</button></form>
      <div class="header-user"><span><?=e($sessionUser['nombre'].' '.$sessionUser['apellido'])?></span><small><?=e(role_label($sessionUser['rol']).(is_encargado() && manager_turn_name()!=='' ? ' · Turno '.manager_turn_name() : ''))?></small></div>
      <a class="header-profile" href="<?=e(url('perfil.php'))?>">Mi perfil</a>
      <a class="header-logout" href="<?=e(url('logout.php'))?>">Cerrar sesión</a>
      <button class="nav-toggle" data-nav-toggle aria-label="Abrir navegación" aria-expanded="false">Menú</button>
    </div>
  </div>
  <div class="nav-strip"><div class="container"><nav class="main-nav" data-main-nav aria-label="Navegación principal">
    <a class="<?=$navActive('/dashboard.php')?>" href="<?=e(url('dashboard.php'))?>">Inicio</a>
    <?php if(is_encargado()): ?>
      <a class="<?=$navActive('/encargado/usuarios.php')?><?=$navActive('/encargado/usuario_')?>" href="<?=e(url('encargado/usuarios.php'))?>">Profesores</a>
      <a class="<?=$navActive('/encargado/salas.php')?><?=$navActive('/encargado/sala_')?><?=$navActive('/sala.php')?>" href="<?=e(url('encargado/salas.php'))?>">Salas</a>
      <a class="<?=$navActive('/mapa_salas.php')?>" href="<?=e(url('mapa_salas.php'))?>">Mapa de salas</a>
      <a class="<?=$navActive('/encargado/horarios.php')?><?=$navActive('/encargado/horario_')?>" href="<?=e(url('encargado/horarios.php'))?>">Horarios</a>
      <a class="<?=$navActive('/encargado/equipos.php')?><?=$navActive('/encargado/equipo_')?>" href="<?=e(url('encargado/equipos.php'))?>">Equipos</a>
      <a class="<?=$navActive('/encargado/perifericos.php')?><?=$navActive('/encargado/periferico_')?>" href="<?=e(url('encargado/perifericos.php'))?>">Periféricos</a>
      <a class="<?=$navActive('/encargado/anuncios.php')?>" href="<?=e(url('encargado/anuncios.php'))?>">Anuncios</a>
      <a class="<?=$navActive('/tickets.php')?><?=$navActive('/ticket.php')?>" href="<?=e(url('tickets.php'))?>">Tickets</a>
    <?php elseif(is_docente()): ?>
      <a class="<?=$navActive('/docente/mi_horario.php')?>" href="<?=e(url('docente/mi_horario.php'))?>">Mi horario</a>
      <a class="<?=$navActive('/mapa_salas.php')?><?=$navActive('/sala.php')?>" href="<?=e(url('mapa_salas.php'))?>">Mapa de salas</a>
      <a class="<?=$navActive('/docente/checkin.php')?>" href="<?=e(url('docente/checkin.php'))?>">Check-In / Out</a>
      <a class="<?=$navActive('/docente/historial_salas.php')?>" href="<?=e(url('docente/historial_salas.php'))?>">Historial de salas</a>
      <a class="<?=$navActive('/docente/nuevo_ticket.php')?>" href="<?=e(url('docente/nuevo_ticket.php'))?>">Reportar falla</a>
      <a class="<?=$navActive('/tickets.php')?><?=$navActive('/ticket.php')?>" href="<?=e(url('tickets.php'))?>">Tickets</a>
    <?php endif; ?>
    <a class="<?=$navActive('/ayuda.php')?>" href="<?=e(url('ayuda.php'))?>">Ayuda</a>
  </nav></div></div>
  <div class="utility-strip"><div class="container utility-links">
    <span>Herramientas</span><a href="<?=e(url('buscar.php'))?>">Búsqueda</a><a href="<?=e(url('perfil.php'))?>">Perfil</a>
    <?php if(is_encargado()):?><a href="<?=e(url('reportes.php'))?>">Reportes</a><a href="<?=e(url('encargado/respaldo.php'))?>">Respaldo</a><?php endif;?>
  </div></div>
</header>
<?php endif; ?>
<main class="<?=$sessionUser?'page-shell':'auth-shell'?>">
<?php if($sessionUser && !$isDashboard): ?><div class="container page-heading"><div><p class="eyebrow">ETSR · UTU / <?=e(role_label($sessionUser['rol']).(is_encargado() && manager_turn_name()!=='' ? ' · Turno '.manager_turn_name() : ''))?></p><h1><?=e($pageTitle)?></h1></div></div><?php endif; ?>
<?php if($flashes): ?><div class="container flash-stack"><?php foreach($flashes as $f): ?><div class="alert alert-<?=e($f['type'])?>"><?=e($f['message'])?></div><?php endforeach; ?></div><?php endif; ?>
