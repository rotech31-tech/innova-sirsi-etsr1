<?php
declare(strict_types=1);

final class CookieSessionHandler implements SessionHandlerInterface
{
    private string $key;
    private string $cookieName='INNOVA_ETSR_DATA';
    private int $ttl;

    public function __construct(string $secret, int $ttl=14400)
    {
        $decoded=base64_decode($secret,true);
        if($decoded===false || strlen($decoded)!==SODIUM_CRYPTO_SECRETBOX_KEYBYTES){
            throw new RuntimeException('SESSION_SECRET inválido.');
        }
        $this->key=$decoded;
        $this->ttl=max(300,$ttl);
    }

    public function open(string $path,string $name):bool{return true;}
    public function close():bool{return true;}

    public function read(string $id):string|false
    {
        $raw=$_COOKIE[$this->cookieName]??'';
        if(!is_string($raw)||$raw==='')return '';
        $bin=base64_decode(strtr($raw,'-_','+/'),true);
        if($bin===false||strlen($bin)<=SODIUM_CRYPTO_SECRETBOX_NONCEBYTES)return '';
        $nonce=substr($bin,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher=substr($bin,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $plain=sodium_crypto_secretbox_open($cipher,$nonce,$this->key);
        if($plain===false)return '';
        $payload=json_decode($plain,true);
        if(!is_array($payload)||($payload['id']??'')!==$id||($payload['exp']??0)<time())return '';
        $data=base64_decode((string)($payload['data']??''),true);
        return $data===false?'':$data;
    }

    public function write(string $id,string $data):bool
    {
        $payload=json_encode(['id'=>$id,'exp'=>time()+$this->ttl,'data'=>base64_encode($data)],JSON_UNESCAPED_SLASHES);
        if($payload===false)return false;
        $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher=sodium_crypto_secretbox($payload,$nonce,$this->key);
        $value=rtrim(strtr(base64_encode($nonce.$cipher),'+/','-_'),'=');
        if(strlen($value)>3800)return false;
        return setcookie($this->cookieName,$value,[
            'expires'=>time()+$this->ttl,'path'=>'/','domain'=>'',
            'secure'=>(!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])&&$_SERVER['HTTP_X_FORWARDED_PROTO']==='https')||(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),
            'httponly'=>true,'samesite'=>'Lax'
        ]);
    }

    public function destroy(string $id):bool
    {
        setcookie($this->cookieName,'',['expires'=>time()-3600,'path'=>'/','secure'=>(!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])&&$_SERVER['HTTP_X_FORWARDED_PROTO']==='https')||(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Lax']);
        return true;
    }
    public function gc(int $max_lifetime):int|false{return 0;}
}
