document.addEventListener('DOMContentLoaded',()=>{
  const t=document.querySelector('[data-nav-toggle]'),n=document.querySelector('[data-main-nav]');
  if(t&&n){
    t.addEventListener('click',()=>{
      const open=n.classList.toggle('is-open');
      t.setAttribute('aria-expanded',open?'true':'false');
    });
    n.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
      n.classList.remove('is-open');
      t.setAttribute('aria-expanded','false');
    }));
  }
  document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{if(!confirm(el.dataset.confirm||'¿Confirmas esta acción?'))e.preventDefault();}));
  const auto=document.querySelector('[data-auto-refresh]');
  if(auto){const ms=parseInt(auto.dataset.autoRefresh||'60000',10);if(ms>=10000)setTimeout(()=>window.location.reload(),ms);}
});

document.addEventListener('DOMContentLoaded',()=>{
  const detail=document.querySelector('[data-map-detail]');
  const stations=[...document.querySelectorAll('[data-map-equipment]')];
  if(detail&&stations.length){
    const empty=detail.querySelector('.map-detail-empty');
    const content=detail.querySelector('.map-detail-content');
    const show=(btn)=>{
      stations.forEach(x=>x.classList.toggle('is-selected',x===btn));
      let data={};try{data=JSON.parse(btn.dataset.mapEquipment||'{}')}catch(e){}
      detail.querySelectorAll('[data-field]').forEach(el=>{el.textContent=data[el.dataset.field]??'-'});
      if(empty)empty.hidden=true;if(content)content.hidden=false;
    };
    stations.forEach(btn=>btn.addEventListener('click',()=>show(btn)));
  }
});

document.addEventListener('DOMContentLoaded',()=>{
  const normalizeCI=value=>(value||'').replace(/\D/g,'');
  const validCI=value=>{
    let digits=normalizeCI(value);
    if(!/^\d{7,8}$/.test(digits)) return false;
    digits=digits.padStart(8,'0');
    if(digits==='00000000') return false;
    const weights=[2,9,8,7,6,3,4];
    let sum=0;
    for(let i=0;i<7;i++) sum+=Number(digits[i])*weights[i];
    const expected=(10-(sum%10))%10;
    return expected===Number(digits[7]);
  };

  document.querySelectorAll('[data-ci-uy]').forEach(input=>{
    const help=input.parentElement?.querySelector('[data-ci-help]');
    const check=()=>{
      const raw=input.value.trim();
      if(!raw){ input.setCustomValidity(''); return true; }
      const ok=validCI(raw);
      input.setCustomValidity(ok?'':'La cédula uruguaya no es válida. Revisa el dígito verificador.');
      if(help){
        help.textContent=ok?'Cédula válida.':'Se valida automáticamente el dígito verificador uruguayo.';
        help.classList.toggle('ci-valid',ok);
      }
      return ok;
    };
    input.addEventListener('blur',check);
    input.addEventListener('input',()=>{input.setCustomValidity('');if(help){help.textContent='Se valida automáticamente el dígito verificador uruguayo.';help.classList.remove('ci-valid');}});
    input.form?.addEventListener('submit',e=>{if(!check()){e.preventDefault();input.reportValidity();input.focus();}});
  });
});

