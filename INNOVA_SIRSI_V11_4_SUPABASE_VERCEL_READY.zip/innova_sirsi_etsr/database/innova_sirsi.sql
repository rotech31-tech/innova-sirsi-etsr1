CREATE DATABASE IF NOT EXISTS innova_sirsi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE innova_sirsi;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS log_actividad;
DROP TABLE IF EXISTS password_resets;
DROP TABLE IF EXISTS comentarios_ticket;
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS sesiones_sala;
DROP TABLE IF EXISTS horarios_docentes;
DROP TABLE IF EXISTS anuncios;
DROP TABLE IF EXISTS perifericos;
DROP TABLE IF EXISTS equipos;
DROP TABLE IF EXISTS asignaciones_salas;
DROP TABLE IF EXISTS salas;
DROP TABLE IF EXISTS usuario_turnos;
DROP TABLE IF EXISTS turnos;
DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE usuarios(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(80) NOT NULL,
 apellido VARCHAR(80) NOT NULL,
 cedula VARCHAR(20) NULL UNIQUE,
 email VARCHAR(150) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 rol ENUM('encargado','docente') NOT NULL,
 foto_perfil VARCHAR(255) NULL,
 activo TINYINT(1) NOT NULL DEFAULT 1,
 eliminado_en DATETIME NULL,
 ultimo_acceso DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_usuarios_rol_activo(rol,activo),
 INDEX idx_usuarios_cedula_email(cedula,email)
)ENGINE=InnoDB;

CREATE TABLE turnos(
 id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(20) NOT NULL UNIQUE,
 nombre VARCHAR(40) NOT NULL UNIQUE,
 activo TINYINT(1) NOT NULL DEFAULT 1,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)ENGINE=InnoDB;

INSERT INTO turnos(id,codigo,nombre,activo) VALUES
(1,'matutino','Matutino',1),
(2,'vespertino','Vespertino',1),
(3,'nocturno','Nocturno',1);

CREATE TABLE usuario_turnos(
 usuario_id BIGINT UNSIGNED NOT NULL,
 turno_id TINYINT UNSIGNED NOT NULL,
 activo TINYINT(1) NOT NULL DEFAULT 1,
 eliminado_en DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(usuario_id,turno_id),
 CONSTRAINT fk_ut_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE,
 CONSTRAINT fk_ut_turno FOREIGN KEY(turno_id) REFERENCES turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 INDEX idx_ut_turno_activo(turno_id,activo,eliminado_en)
)ENGINE=InnoDB;

CREATE TABLE salas(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(100) NOT NULL UNIQUE,
 ubicacion VARCHAR(150) NULL,
 capacidad SMALLINT UNSIGNED NULL,
 descripcion VARCHAR(1000) NULL,
 activa TINYINT(1) NOT NULL DEFAULT 1,
 eliminado_en DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)ENGINE=InnoDB;

CREATE TABLE asignaciones_salas(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 docente_id BIGINT UNSIGNED NOT NULL,
 sala_id BIGINT UNSIGNED NOT NULL,
 turno_id TINYINT UNSIGNED NOT NULL,
 anio_lectivo SMALLINT UNSIGNED NOT NULL,
 activa TINYINT(1) NOT NULL DEFAULT 1,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_asig_doc FOREIGN KEY(docente_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_asig_sala FOREIGN KEY(sala_id) REFERENCES salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_asig_turno FOREIGN KEY(turno_id) REFERENCES turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 UNIQUE KEY uk_asig(docente_id,sala_id,turno_id,anio_lectivo),
 INDEX idx_asig_turno(turno_id,anio_lectivo,activa)
)ENGINE=InnoDB;

CREATE TABLE equipos(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 sala_id BIGINT UNSIGNED NOT NULL,
 codigo_inventario VARCHAR(60) NOT NULL UNIQUE,
 tipo ENUM('pc','torre','monitor','switch','router','impresora','access_point') NOT NULL,
 marca VARCHAR(80) NULL,
 sistema_operativo VARCHAR(100) NULL,
 estado ENUM('operativo','con_falla','mantenimiento','baja') NOT NULL DEFAULT 'operativo',
 observaciones VARCHAR(500) NULL,
 qr_token CHAR(48) NOT NULL UNIQUE,
 activo TINYINT(1) NOT NULL DEFAULT 1,
 eliminado_en DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_equipo_sala FOREIGN KEY(sala_id) REFERENCES salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 INDEX idx_equipo_sala(sala_id,activo),INDEX idx_equipo_estado(estado)
)ENGINE=InnoDB;

CREATE TABLE perifericos(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 equipo_id BIGINT UNSIGNED NOT NULL,
 tipo VARCHAR(60) NOT NULL,
 codigo_inventario_periferico VARCHAR(60) NULL UNIQUE,
 marca VARCHAR(80) NULL,
 estado ENUM('operativo','con_falla','mantenimiento','baja') NOT NULL DEFAULT 'operativo',
 activo TINYINT(1) NOT NULL DEFAULT 1,
 eliminado_en DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_per_eq FOREIGN KEY(equipo_id) REFERENCES equipos(id) ON UPDATE CASCADE ON DELETE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE anuncios(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 encargado_id BIGINT UNSIGNED NOT NULL,
 turno_id TINYINT UNSIGNED NOT NULL,
 titulo VARCHAR(150) NOT NULL,
 contenido TEXT NOT NULL,
 fecha_inicio DATE NULL,
 fecha_fin DATE NULL,
 activo TINYINT(1) NOT NULL DEFAULT 1,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_anuncio_enc FOREIGN KEY(encargado_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_anuncio_turno FOREIGN KEY(turno_id) REFERENCES turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 INDEX idx_anuncio_turno(turno_id,activo,fecha_inicio,fecha_fin)
)ENGINE=InnoDB;

CREATE TABLE horarios_docentes(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 docente_id BIGINT UNSIGNED NOT NULL,
 sala_id BIGINT UNSIGNED NOT NULL,
 turno_id TINYINT UNSIGNED NOT NULL,
 anio_lectivo SMALLINT UNSIGNED NOT NULL,
 dia_semana TINYINT UNSIGNED NOT NULL COMMENT '1=Lunes ... 5=Viernes',
 hora_inicio TIME NOT NULL,
 hora_fin TIME NOT NULL,
 asignatura VARCHAR(120) NULL,
 grupo VARCHAR(80) NULL,
 activo TINYINT(1) NOT NULL DEFAULT 1,
 eliminado_en DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_horario_docente FOREIGN KEY(docente_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_horario_sala FOREIGN KEY(sala_id) REFERENCES salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_horario_turno FOREIGN KEY(turno_id) REFERENCES turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 INDEX idx_horario_busqueda(anio_lectivo,dia_semana,sala_id,hora_inicio),
 INDEX idx_horario_docente(docente_id,anio_lectivo,dia_semana,hora_inicio),
 INDEX idx_horario_turno(turno_id,anio_lectivo,dia_semana,hora_inicio)
)ENGINE=InnoDB;

CREATE TABLE sesiones_sala(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 docente_id BIGINT UNSIGNED NOT NULL,
 sala_id BIGINT UNSIGNED NOT NULL,
 horario_id BIGINT UNSIGNED NULL,
 checkin_en DATETIME NOT NULL,
 checkout_en DATETIME NULL,
 foto_checkin VARCHAR(255) NOT NULL,
 foto_checkout VARCHAR(255) NULL,
 observaciones_checkin VARCHAR(1000) NULL,
 observaciones_checkout VARCHAR(1000) NULL,
 adoptado_desde_sesion_id BIGINT UNSIGNED NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_ses_doc FOREIGN KEY(docente_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_ses_sala FOREIGN KEY(sala_id) REFERENCES salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_sesion_horario FOREIGN KEY(horario_id) REFERENCES horarios_docentes(id) ON UPDATE CASCADE ON DELETE SET NULL,
 CONSTRAINT fk_sesion_adoptada FOREIGN KEY(adoptado_desde_sesion_id) REFERENCES sesiones_sala(id) ON UPDATE CASCADE ON DELETE SET NULL,
 INDEX idx_sesion_adoptada(adoptado_desde_sesion_id),
 INDEX idx_ses_doc(docente_id,checkout_en),
 INDEX idx_sesion_horario_fecha(horario_id,checkin_en)
)ENGINE=InnoDB;

CREATE TABLE tickets(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 equipo_id BIGINT UNSIGNED NULL,
 sala_id BIGINT UNSIGNED NOT NULL,
 docente_id BIGINT UNSIGNED NOT NULL,
 turno_id TINYINT UNSIGNED NOT NULL,
 encargado_id BIGINT UNSIGNED NULL,
 tipo_problema ENUM('equipo_roto','sin_internet','cable_desconectado','no_enciende','software','periferico','red','otro') NOT NULL,
 urgencia ENUM('baja','media','alta','critica') NOT NULL DEFAULT 'media',
 descripcion TEXT NOT NULL,
 foto VARCHAR(255) NULL,
 estado ENUM('abierto','en_revision','en_proceso','resuelto','cerrado') NOT NULL DEFAULT 'abierto',
 resuelto_en DATETIME NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_tick_eq FOREIGN KEY(equipo_id) REFERENCES equipos(id) ON UPDATE CASCADE ON DELETE SET NULL,
 CONSTRAINT fk_tick_sala FOREIGN KEY(sala_id) REFERENCES salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_tick_doc FOREIGN KEY(docente_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_tick_turno FOREIGN KEY(turno_id) REFERENCES turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_tick_enc FOREIGN KEY(encargado_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL,
 INDEX idx_tick_estado(estado,urgencia),INDEX idx_tick_doc(docente_id,creado_en),INDEX idx_tick_turno(turno_id,estado,urgencia)
)ENGINE=InnoDB;

CREATE TABLE comentarios_ticket(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ticket_id BIGINT UNSIGNED NOT NULL,
 usuario_id BIGINT UNSIGNED NOT NULL,
 comentario TEXT NOT NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_com_tick FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON UPDATE CASCADE ON DELETE CASCADE,
 CONSTRAINT fk_com_usr FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE password_resets(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 usuario_id BIGINT UNSIGNED NOT NULL,
 solicitado_por BIGINT UNSIGNED NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expira_en DATETIME NOT NULL,
 usado_en DATETIME NULL,
 ip_solicitud VARCHAR(45) NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_reset_usuario FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE,
 CONSTRAINT fk_reset_solicitante FOREIGN KEY(solicitado_por) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL,
 INDEX idx_reset_usuario_vigencia(usuario_id,usado_en,expira_en),
 INDEX idx_reset_creado(creado_en)
)ENGINE=InnoDB;

CREATE TABLE log_actividad(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 usuario_id BIGINT UNSIGNED NULL,
 accion VARCHAR(100) NOT NULL,
 entidad VARCHAR(60) NULL,
 entidad_id BIGINT UNSIGNED NULL,
 detalle TEXT NULL,
 ip VARCHAR(45) NULL,
 creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_log_usr FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL,
 INDEX idx_log_usuario(usuario_id,creado_en),INDEX idx_log_entidad(entidad,entidad_id)
)ENGINE=InnoDB;
