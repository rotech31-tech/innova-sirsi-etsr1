<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/init.php';
if(!is_post()) redirect('login.php');
verify_csrf();
$email=strtolower(input_string('email',150));
$pass=(string)($_POST['password']??'');
$s=db()->prepare('SELECT id,nombre,apellido,email,password_hash,rol,activo FROM usuarios WHERE email=:e AND eliminado_en IS NULL LIMIT 1');
$s->execute(['e'=>$email]);
$u=$s->fetch();
if(!$u || !(bool)$u['activo'] || !in_array($u['rol'],['encargado','docente'],true) || !password_verify($pass,$u['password_hash'])){
    flash('danger','Correo o contraseña incorrectos, o usuario desactivado.');
    redirect('login.php');
}
$turns=active_turns_for_user((int)$u['id']);
if(!$turns){
    flash('danger','La cuenta no tiene un turno activo asignado. Contacta al Encargado de Sala.');
    redirect('login.php');
}
if($u['rol']==='encargado'){
    // Cada Encargado trabaja en un único turno operativo.
    $u['turno_id']=(int)$turns[0]['id'];
    $u['turno_nombre']=$turns[0]['nombre'];
}
session_regenerate_id(true);
unset($u['password_hash']);
$_SESSION['user']=$u;
db()->prepare('UPDATE usuarios SET ultimo_acceso=NOW() WHERE id=:id')->execute(['id'=>$u['id']]);
log_activity('Inicio de sesión',null,null,$u['rol']==='encargado'?'Turno '.($u['turno_nombre']??''):null);
header('Location: '.safe_intended_url());
exit;
