<?php
declare(strict_types=1);require_once dirname(__DIR__).'/includes/init.php';require_role('encargado');$tipo=(string)($_GET['tipo']??'');$p=db();$turn=manager_turn_id();$rows=[];$headers=[];$filename='reporte.csv';
switch($tipo){
 case 'profesores':
  $headers=['Nombre','Apellido','Cédula','Correo','Activo'];$q=$p->prepare("SELECT DISTINCT u.nombre,u.apellido,u.cedula,u.email,u.activo FROM usuarios u JOIN usuario_turnos ut ON ut.usuario_id=u.id WHERE u.rol='docente' AND u.eliminado_en IS NULL AND ut.turno_id=:t AND ut.eliminado_en IS NULL ORDER BY u.apellido,u.nombre");$q->execute(['t'=>$turn]);$rows=$q->fetchAll(PDO::FETCH_NUM);$filename='profesores_'.date('Ymd').'.csv';break;
 case 'equipos':
  $headers=['Código','Sala','Tipo','Marca','Sistema','Estado','Observaciones'];$rows=$p->query("SELECT e.codigo_inventario,s.nombre,e.tipo,e.marca,e.sistema_operativo,e.estado,e.observaciones FROM equipos e JOIN salas s ON s.id=e.sala_id WHERE e.eliminado_en IS NULL ORDER BY s.nombre,e.codigo_inventario")->fetchAll(PDO::FETCH_NUM);$filename='equipos_'.date('Ymd').'.csv';break;
 case 'tickets':
  $headers=['ID','Fecha','Docente','Sala','Equipo','Problema','Urgencia','Estado','Descripción'];$q=$p->prepare("SELECT t.id,t.creado_en,CONCAT(u.nombre,' ',u.apellido),s.nombre,COALESCE(e.codigo_inventario,'Sin equipo'),t.tipo_problema,t.urgencia,t.estado,t.descripcion FROM tickets t JOIN usuarios u ON u.id=t.docente_id JOIN salas s ON s.id=t.sala_id LEFT JOIN equipos e ON e.id=t.equipo_id WHERE t.turno_id=:t ORDER BY t.creado_en DESC");$q->execute(['t'=>$turn]);$rows=$q->fetchAll(PDO::FETCH_NUM);$filename='tickets_'.date('Ymd').'.csv';break;
 case 'sesiones':
  $headers=['Docente','Sala','Ingreso','Salida','Observación ingreso','Observación salida'];$q=$p->prepare("SELECT DISTINCT CONCAT(u.nombre,' ',u.apellido),s.nombre,ss.checkin_en,ss.checkout_en,ss.observaciones_checkin,ss.observaciones_checkout FROM sesiones_sala ss JOIN usuarios u ON u.id=ss.docente_id JOIN salas s ON s.id=ss.sala_id JOIN usuario_turnos ut ON ut.usuario_id=u.id AND ut.turno_id=:t WHERE ut.eliminado_en IS NULL ORDER BY ss.checkin_en DESC");$q->execute(['t'=>$turn]);$rows=$q->fetchAll(PDO::FETCH_NUM);$filename='historial_salas_'.date('Ymd').'.csv';break;
 default: http_response_code(400);exit('Tipo de reporte no válido.');
}
csv_download_headers($filename);$out=fopen('php://output','w');fputcsv($out,$headers,';');foreach($rows as $row)fputcsv($out,array_map(fn($v)=>$v===null?'':(string)$v,$row),';');fclose($out);exit;
