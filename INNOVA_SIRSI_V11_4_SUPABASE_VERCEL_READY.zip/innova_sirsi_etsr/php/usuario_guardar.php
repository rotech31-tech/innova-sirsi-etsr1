<?php
declare(strict_types=1);require_once dirname(__DIR__).'/includes/init.php';require_role('encargado');if(!is_post())redirect('encargado/usuarios.php');verify_csrf();
$n=input_string('nombre',80);$a=input_string('apellido',80);$cedula=normalize_cedula(input_string('cedula',30));$email=strtolower(input_string('email',150));$pass=(string)($_POST['password']??'');$rol=input_string('rol',20);

// Validaciones separadas para informar exactamente qué dato necesita corrección.
if($n===''){flash('danger','Ingresa el nombre del profesor.');redirect('encargado/usuarios.php');}
if($a===''){flash('danger','Ingresa el apellido del profesor.');redirect('encargado/usuarios.php');}
if(!valid_cedula($cedula)){flash('danger','La cédula uruguaya no es válida. Revisa los números y el dígito verificador. Puedes escribirla con o sin puntos y guion.');redirect('encargado/usuarios.php');}
if(!filter_var($email,FILTER_VALIDATE_EMAIL)){flash('danger','El correo electrónico no tiene un formato válido. Ejemplo: nombre@correo.com');redirect('encargado/usuarios.php');}
if(strlen($pass)<8){flash('danger','La contraseña debe tener al menos 8 caracteres. Actualmente tiene '.strlen($pass).'.');redirect('encargado/usuarios.php');}
if(!in_array($rol,['docente','encargado'],true)){flash('danger','Selecciona un perfil válido para el usuario.');redirect('encargado/usuarios.php');}
$p=db();$turno=$rol==='docente'?manager_turn_id():(input_int('turno_id')??0);$q=$p->prepare('SELECT COUNT(*) FROM turnos WHERE id=:t AND activo=1');$q->execute(['t'=>$turno]);if(!$turno||!(int)$q->fetchColumn()){flash('danger','Selecciona un turno válido.');redirect('encargado/usuarios.php');}
try{
 $foto=$rol==='docente'?upload_image('foto_perfil','docentes',false):null;
 $q=$p->prepare('SELECT * FROM usuarios WHERE cedula=:c OR email=:e LIMIT 1');$q->execute(['c'=>$cedula,'e'=>$email]);$existing=$q->fetch();
 if($existing){
   if($rol!=='docente'||$existing['rol']!=='docente'||normalize_cedula((string)$existing['cedula'])!==$cedula||strtolower((string)$existing['email'])!==$email){throw new RuntimeException('La cédula o el correo ya pertenecen a otra cuenta.');}
   $p->beginTransaction();
   $sql='UPDATE usuarios SET nombre=:n,apellido=:a,activo=1,eliminado_en=NULL'.($foto?',foto_perfil=:f':'').' WHERE id=:id';$params=['n'=>$n,'a'=>$a,'id'=>$existing['id']];if($foto)$params['f']=$foto;$p->prepare($sql)->execute($params);
   $p->prepare('INSERT INTO usuario_turnos(usuario_id,turno_id,activo,eliminado_en) VALUES(:u,:t,1,NULL) ON CONFLICT (usuario_id,turno_id) DO UPDATE SET activo=1,eliminado_en=NULL')->execute(['u'=>$existing['id'],'t'=>$turno]);
   $p->commit();log_activity('Profesor vinculado al turno','usuario_turnos',(int)$existing['id'],'Turno '.turn_name($turno));flash('success','El profesor ya existía y fue vinculado al turno '.turn_name($turno).'.');redirect('encargado/usuarios.php');
 }
 $p->beginTransaction();$s=$p->prepare('INSERT INTO usuarios(nombre,apellido,cedula,email,password_hash,rol,foto_perfil,activo,eliminado_en) VALUES(:n,:a,:c,:e,:p,:r,:f,1,NULL) RETURNING id');$s->execute(['n'=>$n,'a'=>$a,'c'=>$cedula,'e'=>$email,'p'=>password_hash($pass,PASSWORD_BCRYPT),'r'=>$rol,'f'=>$rol==='docente'?$foto:null]);$id=(int)$s->fetchColumn();$p->prepare('INSERT INTO usuario_turnos(usuario_id,turno_id,activo) VALUES(:u,:t,1)')->execute(['u'=>$id,'t'=>$turno]);$p->commit();log_activity('Usuario creado','usuarios',$id,role_label($rol).' · Turno '.turn_name($turno));flash('success',role_label($rol).' creado correctamente para el turno '.turn_name($turno).'.');
}catch(RuntimeException $x){if($p->inTransaction())$p->rollBack();flash('danger',$x->getMessage());}catch(PDOException $x){if($p->inTransaction())$p->rollBack();flash('danger',(($x->getCode()??'')==='23505')?'La cédula o el correo ya están registrados.':'No se pudo crear el usuario.');}
redirect('encargado/usuarios.php');
