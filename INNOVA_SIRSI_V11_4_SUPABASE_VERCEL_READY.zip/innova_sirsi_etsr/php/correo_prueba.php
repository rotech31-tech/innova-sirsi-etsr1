<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/init.php';
require_role('encargado');

if(!is_post()) redirect('encargado/usuarios.php');
verify_csrf();

if(!mail_is_configured()){
    flash('warning','El correo institucional todavía no está configurado.');
    redirect('encargado/usuarios.php');
}

$user=current_user();
$email=(string)($user['email']??'');
$name=trim((string)($user['nombre']??'').' '.(string)($user['apellido']??''));

if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
    flash('danger','Tu cuenta de Encargado no tiene un correo válido para realizar la prueba.');
    redirect('encargado/usuarios.php');
}

$subject='Prueba de correo - '.APP_SHORT_NAME;
$html='<h2>Correo configurado correctamente</h2><p>Este mensaje fue enviado por <strong>'.e(APP_NAME).'</strong>.</p><p>Si lo recibiste, la configuración SMTP está funcionando.</p><p>'.e(COMPANY_NAME).'</p>';
$text="Correo configurado correctamente\n\nEste mensaje fue enviado por ".APP_NAME.".\nSi lo recibiste, la configuración SMTP está funcionando.\n\n".COMPANY_NAME;

if(send_system_mail($email,$name,$subject,$html,$text)){
    log_activity('Correo SMTP de prueba enviado','usuarios',(int)$user['id']);
    flash('success','Correo de prueba enviado a '.$email.'.');
}else{
    flash('danger','No se pudo enviar el correo de prueba. Revisa includes/mail_config.php y los datos SMTP entregados por UTU.');
}

redirect('encargado/usuarios.php');
