<?php
declare(strict_types=1);require_once dirname(__DIR__).'/includes/init.php';require_role('encargado');if(!is_post())redirect('encargado/salas.php');verify_csrf();
$id=input_int('id');$n=input_string('nombre',100);$u=nullable_string('ubicacion',150);$c=input_int('capacidad');$d=nullable_string('descripcion',1000);
if(!$id||$n===''||($c!==null&&($c<1||$c>200))){flash('danger','Revisa los datos de la sala.');redirect('encargado/salas.php');}
try{$s=db()->prepare('UPDATE salas SET nombre=:n,ubicacion=:u,capacidad=:c,descripcion=:d WHERE id=:id AND eliminado_en IS NULL');$s->execute(['n'=>$n,'u'=>$u,'c'=>$c,'d'=>$d,'id'=>$id]);log_activity('Sala editada','salas',$id,$n);flash('success','Sala actualizada correctamente.');}
catch(PDOException $e){flash('danger','No se pudo actualizar la sala. Verifica que el nombre no esté repetido.');}
redirect('encargado/salas.php');
