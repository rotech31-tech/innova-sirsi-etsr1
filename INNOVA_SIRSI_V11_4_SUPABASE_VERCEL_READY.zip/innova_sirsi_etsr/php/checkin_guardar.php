<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/init.php';
require_role('docente');
if(!is_post()) redirect('docente/checkin.php');
verify_csrf();
$uid=(int)current_user()['id'];
$horario=input_int('horario_id');
$modo=input_string('modo',20) ?: 'nuevo';
if(!$horario || !in_array($modo,['nuevo','adoptar'],true)){
    flash('danger','Horario o modalidad inválidos.');
    redirect('docente/checkin.php');
}
$day=(int)date('N');
if($day>5){
    flash('danger','No se pueden registrar clases los sábados o domingos.');
    redirect('docente/checkin.php');
}
$p=db();
$q=$p->prepare("SELECT h.id,h.sala_id FROM horarios_docentes h JOIN salas s ON s.id=h.sala_id WHERE h.id=:h AND h.docente_id=:d AND h.anio_lectivo=YEAR(CURDATE()) AND h.dia_semana=:day AND h.activo=1 AND h.eliminado_en IS NULL AND s.activa=1 AND s.eliminado_en IS NULL LIMIT 1");
$q->execute(['h'=>$horario,'d'=>$uid,'day'=>$day]);
$slot=$q->fetch();
if(!$slot){flash('danger','Ese horario no corresponde a una clase tuya de hoy.');redirect('docente/checkin.php');}
$q=$p->prepare('SELECT COUNT(*) FROM sesiones_sala WHERE docente_id=:d AND checkout_en IS NULL');$q->execute(['d'=>$uid]);
if((int)$q->fetchColumn()>0){flash('danger','Ya tienes una sesión abierta. Debes registrar el Check-Out antes de entrar a otra sala.');redirect('docente/checkin.php');}
$q=$p->prepare('SELECT COUNT(*) FROM sesiones_sala WHERE horario_id=:h AND docente_id=:d AND DATE(checkin_en)=CURDATE()');$q->execute(['h'=>$horario,'d'=>$uid]);
if((int)$q->fetchColumn()>0){flash('danger','Esta clase ya tiene un registro de ingreso hoy.');redirect('docente/checkin.php');}

try{
    $foto=null;$obs=null;$origenId=null;
    if($modo==='adoptar'){
        $origenId=input_int('origen_sesion_id');
        if(!$origenId) throw new RuntimeException('No se pudo identificar el estado que deseas adoptar.');
        $q=$p->prepare("SELECT id,sala_id,foto_checkin,foto_checkout,observaciones_checkin,observaciones_checkout,checkout_en FROM sesiones_sala WHERE id=:id AND sala_id=:s AND checkout_en IS NOT NULL LIMIT 1");
        $q->execute(['id'=>$origenId,'s'=>$slot['sala_id']]);
        $source=$q->fetch();
        if(!$source) throw new RuntimeException('El Check-Out seleccionado ya no está disponible para esta sala.');
        $q=$p->prepare("SELECT COUNT(*) FROM sesiones_sala WHERE sala_id=:s AND checkout_en IS NULL");
        $q->execute(['s'=>$slot['sala_id']]);
        if((int)$q->fetchColumn()>0) throw new RuntimeException('Hay una sesión todavía abierta en esta sala. No se puede adoptar un estado anterior hasta que esa sesión finalice.');
        $q=$p->prepare("SELECT id FROM sesiones_sala WHERE sala_id=:s AND checkout_en IS NOT NULL ORDER BY checkout_en DESC,id DESC LIMIT 1");
        $q->execute(['s'=>$slot['sala_id']]);
        if((int)$q->fetchColumn()!==$origenId) throw new RuntimeException('Existe un Check-Out más reciente. Actualiza la página antes de adoptar el estado.');
        $foto=$source['foto_checkout'] ?: $source['foto_checkin'];
        $obs=trim((string)($source['observaciones_checkout'] ?: $source['observaciones_checkin']));
        $obs=$obs!==''?$obs:null;
        if(!$foto) throw new RuntimeException('El último Check-Out no tiene una imagen disponible para adoptar. Registra un estado nuevo.');
    }else{
        $foto=upload_image('foto_checkin','salas',true);
        $obs=nullable_string('observaciones_checkin',1000);
    }
    $q=$p->prepare('INSERT INTO sesiones_sala(docente_id,sala_id,horario_id,checkin_en,foto_checkin,observaciones_checkin,adoptado_desde_sesion_id) VALUES(:d,:s,:h,NOW(),:f,:o,:origen) RETURNING id');
    $q->execute(['d'=>$uid,'s'=>$slot['sala_id'],'h'=>$horario,'f'=>$foto,'o'=>$obs,'origen'=>$origenId]);
    $newId=(int)$q->fetchColumn();
    log_activity($modo==='adoptar'?'Check-In registrado por adopción':'Check-In registrado','sesiones_sala',$newId,$modo==='adoptar'?'Estado tomado de sesión #'.$origenId:'Horario '.$horario);
    flash('success',$modo==='adoptar'?'Check-In registrado correctamente usando el último estado de la sala.':'Check-In registrado correctamente.');
}catch(RuntimeException $x){
    flash('danger',$x->getMessage());
}catch(PDOException $x){
    flash('danger','No se pudo registrar el Check-In. Verifica la conexión con la base de datos e intenta nuevamente.');
}
redirect('docente/checkin.php');
