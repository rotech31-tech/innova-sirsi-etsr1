<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/init.php';
require_role('docente');
$pageTitle='Check-In / Check-Out';
$uid=(int)current_user()['id'];
$day=(int)date('N');
$year=(int)date('Y');
$requestedOrigin=filter_input(INPUT_GET,'origen',FILTER_VALIDATE_INT) ?: 0;

if($day>5){
    $rows=[];
}else{
    $q=db()->prepare("SELECT h.id horario_id,h.hora_inicio,h.hora_fin,h.asignatura,h.grupo,t.nombre turno,s.id sala_id,s.nombre,s.ubicacion,ss.id sesion_id,ss.checkin_en,ss.checkout_en FROM horarios_docentes h JOIN turnos t ON t.id=h.turno_id JOIN salas s ON s.id=h.sala_id AND s.activa=1 AND s.eliminado_en IS NULL LEFT JOIN sesiones_sala ss ON ss.horario_id=h.id AND ss.docente_id=:d1 AND DATE(ss.checkin_en)=CURDATE() WHERE h.docente_id=:d2 AND h.anio_lectivo=:y AND h.dia_semana=:day AND h.activo=1 AND h.eliminado_en IS NULL ORDER BY h.hora_inicio,s.nombre");
    $q->execute(['d1'=>$uid,'d2'=>$uid,'y'=>$year,'day'=>$day]);
    $rows=$q->fetchAll();
}

$lastByRoom=[];
$lastStmt=db()->prepare("SELECT ss.id,ss.sala_id,ss.checkin_en,ss.checkout_en,ss.foto_checkin,ss.foto_checkout,ss.observaciones_checkin,ss.observaciones_checkout,CONCAT(u.nombre,' ',u.apellido) docente FROM sesiones_sala ss JOIN usuarios u ON u.id=ss.docente_id WHERE ss.sala_id=:s AND ss.checkout_en IS NOT NULL ORDER BY ss.checkout_en DESC,ss.id DESC LIMIT 1");
foreach($rows as $r){
    if(!$r['sesion_id'] && !isset($lastByRoom[(int)$r['sala_id']])){
        $lastStmt->execute(['s'=>$r['sala_id']]);
        $lastByRoom[(int)$r['sala_id']]=$lastStmt->fetch() ?: null;
    }
}
require dirname(__DIR__).'/includes/header.php';
?>
<section class="card"><div class="card-header"><h2><?=e($day<=5?day_name($day):'Día no lectivo')?> · clases de hoy</h2><a class="btn btn-secondary btn-small" href="<?=e(url('docente/mi_horario.php'))?>">Ver semana</a></div><div class="card-body">
<?php if(!$rows):?>
  <div class="empty-state">No tienes clases programadas en salas de informática para hoy.</div>
<?php else:?><div class="grid grid-2">
<?php foreach($rows as $r): $last=$lastByRoom[(int)$r['sala_id']]??null; ?>
<article class="card" id="horario-<?=(int)$r['horario_id']?>"><div class="card-body">
  <p class="eyebrow"><?=e(format_time($r['hora_inicio']).' - '.format_time($r['hora_fin']))?></p>
  <h3 class="mt-0"><?=e($r['nombre'])?></h3><p class="meta">Turno <?=e($r['turno'])?></p>
  <?php if($r['asignatura']):?><p class="text-muted"><?=e($r['asignatura'])?><?=$r['grupo']?' · '.e($r['grupo']):''?></p><?php endif;?>

  <?php if(!$r['sesion_id']):?>
    <?php if($last):?>
      <div class="previous-state <?=$requestedOrigin===(int)$last['id']?'previous-state--selected':''?>">
        <strong>Último Check-Out de esta sala</strong>
        <p class="meta">Registrado por <?=e($last['docente'])?> · <?=e(date('d/m/Y H:i',strtotime($last['checkout_en'])))?></p>
        <?php $lastObs=trim((string)($last['observaciones_checkout']?:$last['observaciones_checkin'])); ?>
        <?php if($lastObs!==''):?><p><?=nl2br(e($lastObs))?></p><?php else:?><p class="text-muted">Sin observaciones registradas.</p><?php endif;?>
        <div class="form-actions">
          <?php $statePhoto=$last['foto_checkout']?:$last['foto_checkin']; if($statePhoto):?><a class="btn btn-secondary btn-small" href="<?=e(url($statePhoto))?>" target="_blank">Ver foto del estado</a><?php endif;?>
          <form action="<?=e(url('php/checkin_guardar.php'))?>" method="post">
            <?=csrf_field()?>
            <input type="hidden" name="horario_id" value="<?=(int)$r['horario_id']?>">
            <input type="hidden" name="modo" value="adoptar">
            <input type="hidden" name="origen_sesion_id" value="<?=(int)$last['id']?>">
            <button class="btn btn-success">Adoptar este estado como Check-In</button>
          </form>
        </div>
        <p class="form-help">Se crea un Check-In nuevo a tu nombre y con la hora actual. Solo se reutilizan la foto y las observaciones del estado de la sala; no se copia ninguna sesión ni dato de acceso del profesor anterior.</p>
      </div>
      <div class="state-divider"><span>o registrar un estado nuevo</span></div>
    <?php endif;?>
    <form action="<?=e(url('php/checkin_guardar.php'))?>" method="post" enctype="multipart/form-data">
      <?=csrf_field()?>
      <input type="hidden" name="horario_id" value="<?=(int)$r['horario_id']?>">
      <input type="hidden" name="modo" value="nuevo">
      <div class="form-group"><label>Foto actual de la sala</label><input name="foto_checkin" type="file" accept="image/jpeg,image/png,image/webp" capture="environment" required></div>
      <div class="form-group mt-2"><label>Estado / observaciones de la sala y los equipos</label><textarea name="observaciones_checkin" maxlength="1000"></textarea></div>
      <div class="form-actions"><button class="btn btn-primary">Registrar estado nuevo</button></div>
    </form>
  <?php elseif(!$r['checkout_en']):?>
    <div class="alert alert-info">En sala desde <?=e(date('H:i',strtotime($r['checkin_en'])))?>.</div>
    <form action="<?=e(url('php/checkout_guardar.php'))?>" method="post" enctype="multipart/form-data">
      <?=csrf_field()?>
      <input type="hidden" name="sesion_id" value="<?=(int)$r['sesion_id']?>">
      <div class="form-group"><label>Foto al retirarte</label><input name="foto_checkout" type="file" accept="image/jpeg,image/png,image/webp" capture="environment"></div>
      <div class="form-group mt-2"><label>Estado / observaciones finales de la sala y los equipos</label><textarea name="observaciones_checkout" maxlength="1000"></textarea></div>
      <div class="form-actions"><button class="btn btn-success">Registrar Check-Out</button></div>
    </form>
  <?php else:?>
    <div class="alert alert-success">Clase registrada: <?=e(date('H:i',strtotime($r['checkin_en'])))?> a <?=e(date('H:i',strtotime($r['checkout_en'])))?>.</div>
  <?php endif;?>
</div></article>
<?php endforeach;?>
</div><?php endif;?>
</div></section>
<?php require dirname(__DIR__).'/includes/footer.php';?>
