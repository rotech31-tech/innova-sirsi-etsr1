<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/init.php';
require_role('docente');
$pageTitle='Mi horario semanal';
$uid=(int)current_user()['id'];$year=(int)date('Y');
$q=db()->prepare("SELECT h.*,s.nombre sala,s.ubicacion,t.nombre turno FROM horarios_docentes h JOIN salas s ON s.id=h.sala_id JOIN turnos t ON t.id=h.turno_id WHERE h.docente_id=:d AND h.anio_lectivo=:y AND h.activo=1 AND h.eliminado_en IS NULL AND s.eliminado_en IS NULL ORDER BY h.dia_semana,h.hora_inicio,s.nombre");$q->execute(['d'=>$uid,'y'=>$year]);$rows=$q->fetchAll();
$byDay=[];foreach($rows as $r)$byDay[(int)$r['dia_semana']][]=$r;
require dirname(__DIR__).'/includes/header.php';
?>
<section class="card"><div class="card-header"><h2>Horario <?=date('Y')?></h2></div><div class="card-body"><?php if(!$rows):?><div class="empty-state">Todavía no tienes horarios cargados para el año actual.</div><?php else:?><div class="schedule-week"><?php for($day=1;$day<=5;$day++):?><article class="schedule-day"><h3><?=e(day_name($day))?></h3><?php if(empty($byDay[$day])):?><p class="text-muted">Sin clases asignadas.</p><?php else:?><?php foreach($byDay[$day] as $r):?><div class="schedule-slot"><strong><?=e(format_time($r['hora_inicio']).' - '.format_time($r['hora_fin']))?></strong><span><?=e($r['sala'])?> · <?=e($r['turno'])?></span><?php if($r['asignatura']):?><small><?=e($r['asignatura'])?><?=$r['grupo']?' · '.e($r['grupo']):''?></small><?php endif;?></div><?php endforeach;?><?php endif;?></article><?php endfor;?></div><?php endif;?></div></section>
<?php require dirname(__DIR__).'/includes/footer.php';?>
