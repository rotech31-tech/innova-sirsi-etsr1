<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/includes/init.php';
require_role('docente');
$pageTitle='Historial de salas';
$p=db();
$salaId=filter_input(INPUT_GET,'sala_id',FILTER_VALIDATE_INT) ?: 0;
$fecha=trim((string)($_GET['fecha']??''));
if($fecha!=='' && !valid_date($fecha)) $fecha='';
$rooms=$p->query('SELECT id,nombre FROM salas WHERE eliminado_en IS NULL ORDER BY nombre')->fetchAll();

$sql="SELECT ss.*,s.nombre sala,CONCAT(u.nombre,' ',u.apellido) docente,src.checkout_en origen_checkout,CONCAT(su.nombre,' ',su.apellido) origen_docente FROM sesiones_sala ss JOIN salas s ON s.id=ss.sala_id JOIN usuarios u ON u.id=ss.docente_id LEFT JOIN sesiones_sala src ON src.id=ss.adoptado_desde_sesion_id LEFT JOIN usuarios su ON su.id=src.docente_id WHERE 1=1";
$params=[];
if($salaId){$sql.=' AND ss.sala_id=:sala';$params['sala']=$salaId;}
if($fecha!==''){$sql.=' AND DATE(ss.checkin_en)=:fecha';$params['fecha']=$fecha;}
$sql.=' ORDER BY ss.checkin_en DESC LIMIT 200';
$q=$p->prepare($sql);$q->execute($params);$rows=$q->fetchAll();

$latest=[];
$q=$p->query("SELECT a.id,a.sala_id FROM sesiones_sala a WHERE a.checkout_en IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sesiones_sala b WHERE b.sala_id=a.sala_id AND b.checkout_en IS NOT NULL AND (b.checkout_en>a.checkout_en OR (b.checkout_en=a.checkout_en AND b.id>a.id)))");
foreach($q->fetchAll() as $x)$latest[(int)$x['sala_id']]=(int)$x['id'];

$available=[];
$today=(int)date('N');
if($today<=5){
    $q=$p->prepare("SELECT h.sala_id FROM horarios_docentes h LEFT JOIN sesiones_sala ss ON ss.horario_id=h.id AND ss.docente_id=:d1 AND DATE(ss.checkin_en)=CURDATE() WHERE h.docente_id=:d2 AND h.anio_lectivo=YEAR(CURDATE()) AND h.dia_semana=:day AND h.activo=1 AND h.eliminado_en IS NULL AND ss.id IS NULL");
    $q->execute(['d1'=>current_user()['id'],'d2'=>current_user()['id'],'day'=>$today]);
    foreach($q->fetchAll() as $x)$available[(int)$x['sala_id']]=true;
}
require dirname(__DIR__).'/includes/header.php';
?>
<section class="card"><div class="card-header"><div><h2>Registros de Check-In y Check-Out</h2><p class="meta mt-0">Se muestran únicamente datos del uso de la sala: docente, fecha, horarios, fotos y observaciones cargadas.</p></div></div><div class="card-body"><form method="get" class="filter-bar"><div class="form-group"><label>Sala</label><select name="sala_id"><option value="">Todas</option><?php foreach($rooms as $r):?><option value="<?=(int)$r['id']?>" <?=$salaId===(int)$r['id']?'selected':''?>><?=e($r['nombre'])?></option><?php endforeach;?></select></div><div class="form-group"><label>Fecha</label><input type="date" name="fecha" value="<?=e($fecha)?>"></div><button class="btn btn-primary">Filtrar</button><a class="btn btn-secondary" href="<?=e(url('docente/historial_salas.php'))?>">Limpiar</a></form></div>
<div class="history-summary">
<?php foreach(array_slice($rows,0,6) as $h):?>
  <article class="history-card"><div><strong><?=e($h['sala'])?></strong><span><?=e($h['docente'])?></span></div><div><b><?=e(format_datetime($h['checkin_en']))?></b><small><?=$h['checkout_en']?'Salida '.e(date('H:i',strtotime($h['checkout_en']))):'Sesión abierta'?></small></div></article>
<?php endforeach;?>
</div><div class="table-wrap"><?php if(!$rows):?><div class="empty-state">No hay registros para los filtros seleccionados.</div><?php else:?><table><thead><tr><th>Sala</th><th>Docente</th><th>Fecha</th><th>Ingreso</th><th>Salida</th><th>Estado cargado</th><th>Fotos</th><th></th></tr></thead><tbody>
<?php foreach($rows as $r): $obsIn=trim((string)$r['observaciones_checkin']);$obsOut=trim((string)$r['observaciones_checkout']);$isLatest=isset($latest[(int)$r['sala_id']])&&$latest[(int)$r['sala_id']]===(int)$r['id']; ?>
<tr><td><strong><?=e($r['sala'])?></strong><?php if($r['adoptado_desde_sesion_id']):?><div class="meta">Check-In adoptado<?php if($r['origen_docente']):?> desde estado de <?=e($r['origen_docente'])?><?php endif;?></div><?php endif;?></td><td><?=e($r['docente'])?></td><td><?=e(date('d/m/Y',strtotime($r['checkin_en'])))?></td><td><?=e(date('H:i',strtotime($r['checkin_en'])))?></td><td><?=$r['checkout_en']?e(date('H:i',strtotime($r['checkout_en']))):'<span class="badge badge-info">Abierta</span>'?></td><td><?php if($obsIn!==''):?><strong>Ingreso:</strong> <?=nl2br(e($obsIn))?><?php endif;?><?php if($obsOut!==''):?><div class="meta"><strong>Salida:</strong> <?=nl2br(e($obsOut))?></div><?php endif;?><?php if($obsIn===''&&$obsOut===''):?><span class="text-muted">Sin observaciones</span><?php endif;?></td><td><a href="<?=e(url($r['foto_checkin']))?>" target="_blank">Entrada</a><?php if($r['foto_checkout']):?> · <a href="<?=e(url($r['foto_checkout']))?>" target="_blank">Salida</a><?php endif;?></td><td><?php if($r['checkout_en']&&$isLatest&&!empty($available[(int)$r['sala_id']])):?><a class="btn btn-secondary btn-small" href="<?=e(url('docente/checkin.php?origen='.(int)$r['id']))?>">Adoptar en Check-In</a><?php endif;?></td></tr>
<?php endforeach;?></tbody></table><?php endif;?></div></section>
<?php require dirname(__DIR__).'/includes/footer.php';?>
