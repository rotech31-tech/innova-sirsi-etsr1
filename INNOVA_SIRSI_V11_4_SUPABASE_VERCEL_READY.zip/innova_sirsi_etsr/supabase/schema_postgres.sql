DROP SCHEMA IF EXISTS app CASCADE;
CREATE SCHEMA app;

CREATE OR REPLACE FUNCTION app.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.actualizado_en = CURRENT_TIMESTAMP;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION app.curdate()
RETURNS date LANGUAGE sql STABLE AS $$ SELECT CURRENT_DATE $$;

CREATE OR REPLACE FUNCTION app.year(d date)
RETURNS integer LANGUAGE sql IMMUTABLE AS $$ SELECT EXTRACT(YEAR FROM d)::integer $$;

CREATE OR REPLACE FUNCTION app.year(ts timestamp)
RETURNS integer LANGUAGE sql IMMUTABLE AS $$ SELECT EXTRACT(YEAR FROM ts)::integer $$;

CREATE TABLE app.usuarios(
 id BIGSERIAL PRIMARY KEY,
 nombre VARCHAR(80) NOT NULL,
 apellido VARCHAR(80) NOT NULL,
 cedula VARCHAR(20) UNIQUE,
 email VARCHAR(150) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 rol VARCHAR(20) NOT NULL CHECK (rol IN ('encargado','docente')),
 foto_perfil VARCHAR(255),
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 eliminado_en TIMESTAMP NULL,
 ultimo_acceso TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_usuarios_rol_activo ON app.usuarios(rol,activo);
CREATE INDEX idx_usuarios_cedula_email ON app.usuarios(cedula,email);

CREATE TABLE app.turnos(
 id SMALLSERIAL PRIMARY KEY,
 codigo VARCHAR(20) NOT NULL UNIQUE,
 nombre VARCHAR(40) NOT NULL UNIQUE,
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO app.turnos(id,codigo,nombre,activo) VALUES
(1,'matutino','Matutino',1),(2,'vespertino','Vespertino',1),(3,'nocturno','Nocturno',1);
SELECT setval(pg_get_serial_sequence('app.turnos','id'), 3, true);

CREATE TABLE app.usuario_turnos(
 usuario_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE,
 turno_id SMALLINT NOT NULL REFERENCES app.turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 eliminado_en TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(usuario_id,turno_id)
);
CREATE INDEX idx_ut_turno_activo ON app.usuario_turnos(turno_id,activo,eliminado_en);

CREATE TABLE app.salas(
 id BIGSERIAL PRIMARY KEY,
 nombre VARCHAR(100) NOT NULL UNIQUE,
 ubicacion VARCHAR(150),
 capacidad SMALLINT,
 descripcion VARCHAR(1000),
 activa SMALLINT NOT NULL DEFAULT 1 CHECK (activa IN (0,1)),
 eliminado_en TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app.asignaciones_salas(
 id BIGSERIAL PRIMARY KEY,
 docente_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 sala_id BIGINT NOT NULL REFERENCES app.salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 turno_id SMALLINT NOT NULL REFERENCES app.turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 anio_lectivo SMALLINT NOT NULL,
 activa SMALLINT NOT NULL DEFAULT 1 CHECK (activa IN (0,1)),
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(docente_id,sala_id,turno_id,anio_lectivo)
);
CREATE INDEX idx_asig_turno ON app.asignaciones_salas(turno_id,anio_lectivo,activa);

CREATE TABLE app.equipos(
 id BIGSERIAL PRIMARY KEY,
 sala_id BIGINT NOT NULL REFERENCES app.salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 codigo_inventario VARCHAR(60) NOT NULL UNIQUE,
 tipo VARCHAR(30) NOT NULL CHECK (tipo IN ('pc','torre','monitor','switch','router','impresora','access_point')),
 marca VARCHAR(80),
 sistema_operativo VARCHAR(100),
 estado VARCHAR(30) NOT NULL DEFAULT 'operativo' CHECK (estado IN ('operativo','con_falla','mantenimiento','baja')),
 observaciones VARCHAR(500),
 qr_token CHAR(48) NOT NULL UNIQUE,
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 eliminado_en TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_equipo_sala ON app.equipos(sala_id,activo);
CREATE INDEX idx_equipo_estado ON app.equipos(estado);

CREATE TABLE app.perifericos(
 id BIGSERIAL PRIMARY KEY,
 equipo_id BIGINT NOT NULL REFERENCES app.equipos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 tipo VARCHAR(60) NOT NULL,
 codigo_inventario_periferico VARCHAR(60) UNIQUE,
 marca VARCHAR(80),
 modelo VARCHAR(100),
 numero_serie VARCHAR(120) UNIQUE,
 estado VARCHAR(30) NOT NULL DEFAULT 'operativo' CHECK (estado IN ('operativo','con_falla','mantenimiento','baja')),
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 eliminado_en TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app.anuncios(
 id BIGSERIAL PRIMARY KEY,
 encargado_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 turno_id SMALLINT NOT NULL REFERENCES app.turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 titulo VARCHAR(150) NOT NULL,
 contenido TEXT NOT NULL,
 fecha_inicio DATE,
 fecha_fin DATE,
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_anuncio_turno ON app.anuncios(turno_id,activo,fecha_inicio,fecha_fin);

CREATE TABLE app.horarios_docentes(
 id BIGSERIAL PRIMARY KEY,
 docente_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 sala_id BIGINT NOT NULL REFERENCES app.salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 turno_id SMALLINT NOT NULL REFERENCES app.turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 anio_lectivo SMALLINT NOT NULL,
 dia_semana SMALLINT NOT NULL CHECK (dia_semana BETWEEN 1 AND 5),
 hora_inicio TIME NOT NULL,
 hora_fin TIME NOT NULL,
 asignatura VARCHAR(120),
 grupo VARCHAR(80),
 activo SMALLINT NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
 eliminado_en TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_horario_busqueda ON app.horarios_docentes(anio_lectivo,dia_semana,sala_id,hora_inicio);
CREATE INDEX idx_horario_docente ON app.horarios_docentes(docente_id,anio_lectivo,dia_semana,hora_inicio);
CREATE INDEX idx_horario_turno ON app.horarios_docentes(turno_id,anio_lectivo,dia_semana,hora_inicio);

CREATE TABLE app.sesiones_sala(
 id BIGSERIAL PRIMARY KEY,
 docente_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 sala_id BIGINT NOT NULL REFERENCES app.salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 horario_id BIGINT REFERENCES app.horarios_docentes(id) ON UPDATE CASCADE ON DELETE SET NULL,
 checkin_en TIMESTAMP NOT NULL,
 checkout_en TIMESTAMP NULL,
 foto_checkin VARCHAR(255) NOT NULL,
 foto_checkout VARCHAR(255),
 observaciones_checkin VARCHAR(1000),
 observaciones_checkout VARCHAR(1000),
 adoptado_desde_sesion_id BIGINT REFERENCES app.sesiones_sala(id) ON UPDATE CASCADE ON DELETE SET NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_sesion_adoptada ON app.sesiones_sala(adoptado_desde_sesion_id);
CREATE INDEX idx_ses_doc ON app.sesiones_sala(docente_id,checkout_en);
CREATE INDEX idx_sesion_horario_fecha ON app.sesiones_sala(horario_id,checkin_en);

CREATE TABLE app.tickets(
 id BIGSERIAL PRIMARY KEY,
 equipo_id BIGINT REFERENCES app.equipos(id) ON UPDATE CASCADE ON DELETE SET NULL,
 sala_id BIGINT NOT NULL REFERENCES app.salas(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 docente_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 turno_id SMALLINT NOT NULL REFERENCES app.turnos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 encargado_id BIGINT REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL,
 tipo_problema VARCHAR(30) NOT NULL CHECK (tipo_problema IN ('equipo_roto','sin_internet','cable_desconectado','no_enciende','software','periferico','red','otro')),
 urgencia VARCHAR(20) NOT NULL DEFAULT 'media' CHECK (urgencia IN ('baja','media','alta','critica')),
 descripcion TEXT NOT NULL,
 foto VARCHAR(255),
 estado VARCHAR(30) NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','en_revision','en_proceso','resuelto','cerrado')),
 resuelto_en TIMESTAMP NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_tick_estado ON app.tickets(estado,urgencia);
CREATE INDEX idx_tick_doc ON app.tickets(docente_id,creado_en);
CREATE INDEX idx_tick_turno ON app.tickets(turno_id,estado,urgencia);

CREATE TABLE app.comentarios_ticket(
 id BIGSERIAL PRIMARY KEY,
 ticket_id BIGINT NOT NULL REFERENCES app.tickets(id) ON UPDATE CASCADE ON DELETE CASCADE,
 usuario_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
 comentario TEXT NOT NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app.password_resets(
 id BIGSERIAL PRIMARY KEY,
 usuario_id BIGINT NOT NULL REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE,
 solicitado_por BIGINT REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expira_en TIMESTAMP NOT NULL,
 usado_en TIMESTAMP NULL,
 ip_solicitud VARCHAR(45),
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_reset_usuario_vigencia ON app.password_resets(usuario_id,usado_en,expira_en);
CREATE INDEX idx_reset_creado ON app.password_resets(creado_en);

CREATE TABLE app.log_actividad(
 id BIGSERIAL PRIMARY KEY,
 usuario_id BIGINT REFERENCES app.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL,
 accion VARCHAR(100) NOT NULL,
 entidad VARCHAR(60),
 entidad_id BIGINT,
 detalle TEXT,
 ip VARCHAR(45),
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_log_usuario ON app.log_actividad(usuario_id,creado_en);
CREATE INDEX idx_log_entidad ON app.log_actividad(entidad,entidad_id);

CREATE TABLE app.archivos(
 id BIGSERIAL PRIMARY KEY,
 token CHAR(48) NOT NULL UNIQUE,
 categoria VARCHAR(40) NOT NULL,
 mime VARCHAR(80) NOT NULL,
 nombre_original VARCHAR(255),
 contenido BYTEA NOT NULL,
 tamano INTEGER NOT NULL,
 creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_archivos_token ON app.archivos(token);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['usuarios','usuario_turnos','salas','asignaciones_salas','equipos','perifericos','anuncios','horarios_docentes','sesiones_sala','tickets'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%I_updated BEFORE UPDATE ON app.%I FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at()', t, t);
  END LOOP;
END $$;

